const state = {
  authed: false,
  otpStep: false,
  role: "investor",
  page: "dashboard",
  user: { name: "Alex Morgan", email: "alex@nexus.com", wallet: 250000 },
  meetings: [
    { id: 1, title: "Series A Pitch Discussion", with: "Sarah Chen", date: "2026-04-15", time: "10:00", status: "confirmed" },
    { id: 2, title: "Due Diligence Review", with: "Marcus Rivera", date: "2026-04-16", time: "14:00", status: "pending" },
    { id: 3, title: "Product Demo", with: "Emily Park", date: "2026-04-18", time: "09:00", status: "pending" }
  ],
  docs: [
    { id: 1, title: "Series A Investment Agreement", type: "PDF", status: "review", signed: false },
    { id: 2, title: "NDA - TechVenture Inc.", type: "PDF", status: "signed", signed: true },
    { id: 3, title: "Term Sheet Draft", type: "DOCX", status: "draft", signed: false }
  ],
  txs: [
    { id: 1, type: "deposit", amount: 50000, sender: "Bank", receiver: "You", status: "completed", date: "2026-04-10" },
    { id: 2, type: "funding", amount: 15000, sender: "You", receiver: "TechVenture Inc.", status: "completed", date: "2026-04-08" },
    { id: 3, type: "withdraw", amount: 5000, sender: "You", receiver: "Bank", status: "completed", date: "2026-04-05" }
  ],
  deals: [
    { id: 1, title: "AI-Driven Logistics Platform", target: 500000, raised: 325000, founder: "Sarah Chen" },
    { id: 2, title: "GreenEnergy Labs", target: 250000, raised: 100000, founder: "Emily Park" }
  ],
  call: { active: false, video: true, audio: true, screen: false },
  tour: true
};

const app = document.getElementById("app");
const money = n => `$${Number(n).toLocaleString()}`;
const status = s => `<span class="status ${s}">${s.replace("_", " ")}</span>`;

function render() {
  if (!state.authed) return renderLogin();
  app.innerHTML = `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="side-brand"><span class="brand-mark">N</span><span>Nexus</span></div>
        <nav class="nav">
          ${navButton("dashboard", "Dashboard")}
          ${navButton("calendar", "Meetings")}
          ${navButton("video", "Video Call")}
          ${navButton("documents", "Documents")}
          ${navButton("payments", "Payments")}
          ${navButton("security", "Security")}
        </nav>
        <div class="user-card">
          <strong>${state.user.name}</strong><br />
          <span class="muted">${state.role}</span>
          <br /><br />
          <button class="ghost-btn" onclick="logout()">Sign Out</button>
        </div>
      </aside>
      <main class="main">
        <header class="topbar"><h2>${pageTitle()}</h2><span class="muted">${state.user.email}</span></header>
        <section class="content">${pageMarkup()}</section>
      </main>
    </div>
    ${state.tour ? tourMarkup() : ""}
  `;
  attachSignatureEvents();
}

function navButton(id, label) {
  return `<button class="${state.page === id ? "active" : ""}" onclick="go('${id}')">${label}</button>`;
}

function pageTitle() {
  return {
    dashboard: "Dashboard",
    calendar: "Meeting Calendar",
    video: "Video Call",
    documents: "Document Chamber",
    payments: "Payment Center",
    security: "Security & Access"
  }[state.page];
}

function go(page) {
  state.page = page;
  render();
}

function logout() {
  state.authed = false;
  state.otpStep = false;
  render();
}

function renderLogin() {
  app.innerHTML = `
    <div class="login-screen">
      <div class="login-box">
        <div class="brand"><span class="brand-mark">N</span><h1>Nexus</h1><p>Investor & Entrepreneur Collaboration Platform</p></div>
        ${state.otpStep ? otpMarkup() : loginFormMarkup()}
      </div>
    </div>
  `;
}

function loginFormMarkup() {
  return `
    <div class="role-switch">
      <button class="${state.role === "investor" ? "active" : ""}" onclick="setRole('investor')">Investor</button>
      <button class="${state.role === "entrepreneur" ? "active" : ""}" onclick="setRole('entrepreneur')">Entrepreneur</button>
    </div>
    <div class="field"><label>Email</label><input id="email" type="email" value="alex@nexus.com" /></div>
    <div class="field"><label>Password</label><input id="password" type="password" oninput="updateStrength(this.value)" placeholder="Enter password" /><div class="strength"><span id="strengthBar"></span></div><small id="strengthText" class="muted">Password strength</small></div>
    <button class="primary-btn" style="width:100%" onclick="startLogin()">Sign In</button>
    <p class="muted" style="text-align:center;font-size:13px">Demo OTP: 123456</p>
  `;
}

function otpMarkup() {
  return `
    <h2 style="text-align:center">Two-Factor Authentication</h2>
    <p class="muted" style="text-align:center">Enter demo OTP 123456</p>
    <div class="otp-row">${[0,1,2,3,4,5].map(i => `<input maxlength="1" id="otp${i}" oninput="nextOtp(${i})" />`).join("")}</div>
    <button class="primary-btn" style="width:100%" onclick="verifyOtp()">Verify OTP</button>
    <button class="ghost-btn" style="width:100%;margin-top:10px" onclick="state.otpStep=false;render()">Back</button>
  `;
}

function setRole(role) {
  state.role = role;
  state.user.wallet = role === "investor" ? 250000 : 50000;
  render();
}

function updateStrength(value) {
  let score = 0;
  if (value.length >= 8) score++;
  if (/[A-Z]/.test(value)) score++;
  if (/\d/.test(value)) score++;
  if (/[^A-Za-z0-9]/.test(value)) score++;
  const bar = document.getElementById("strengthBar");
  const text = document.getElementById("strengthText");
  const colors = ["#ef4444", "#f59e0b", "#f59e0b", "#10b981"];
  const labels = ["Weak", "Fair", "Good", "Strong"];
  bar.style.width = `${score * 25}%`;
  bar.style.background = colors[Math.max(score - 1, 0)];
  text.textContent = score ? labels[score - 1] : "Password strength";
}

function startLogin() {
  state.user.email = document.getElementById("email").value || "alex@nexus.com";
  state.user.name = state.user.email.split("@")[0];
  state.otpStep = true;
  render();
}

function nextOtp(i) {
  const el = document.getElementById(`otp${i}`);
  if (el.value && i < 5) document.getElementById(`otp${i + 1}`).focus();
}

function verifyOtp() {
  const code = [0,1,2,3,4,5].map(i => document.getElementById(`otp${i}`).value).join("");
  if (code === "123456") {
    state.authed = true;
    state.otpStep = false;
    state.page = "dashboard";
    render();
  } else {
    alert("Invalid OTP. Use 123456.");
  }
}

function pageMarkup() {
  return {
    dashboard: dashboardMarkup,
    calendar: calendarMarkup,
    video: videoMarkup,
    documents: documentsMarkup,
    payments: paymentsMarkup,
    security: securityMarkup
  }[state.page]();
}

function dashboardMarkup() {
  return `
    <div class="grid-4">
      <div class="stat"><span class="muted">Wallet Balance</span><strong>${money(state.user.wallet)}</strong></div>
      <div class="stat"><span class="muted">Active Deals</span><strong>${state.deals.length}</strong></div>
      <div class="stat"><span class="muted">Documents</span><strong>${state.docs.length}</strong></div>
      <div class="stat"><span class="muted">Meetings</span><strong>${state.meetings.filter(m => m.status === "confirmed").length}</strong></div>
    </div>
    <br />
    <div class="grid-2">
      <div class="panel"><h3>Upcoming Meetings</h3><div class="list">${state.meetings.map(meetingItem).join("")}</div></div>
      <div class="panel"><h3>Active Deals</h3><div class="list">${state.deals.map(dealItem).join("")}</div></div>
    </div>
  `;
}

function meetingItem(m) {
  return `<div class="item"><div><strong>${m.title}</strong><br /><span class="muted">${m.with} - ${m.date} at ${m.time}</span></div>${status(m.status)}</div>`;
}

function dealItem(d) {
  const pct = Math.min(100, Math.round((d.raised / d.target) * 100));
  return `<div class="item"><div style="width:100%"><strong>${d.title}</strong><br /><span class="muted">Founder: ${d.founder}</span><div class="strength"><span style="width:${pct}%;background:#2563eb"></span></div><small>${money(d.raised)} of ${money(d.target)} raised</small></div></div>`;
}

function calendarMarkup() {
  return `
    <div class="panel">
      <h3>Schedule New Meeting</h3>
      <div class="grid-3">
        <div class="field"><label>Title</label><input id="meetingTitle" placeholder="Meeting title" /></div>
        <div class="field"><label>With</label><input id="meetingWith" placeholder="Name" /></div>
        <div class="field"><label>Date</label><input id="meetingDate" type="date" /></div>
      </div>
      <button class="primary-btn" onclick="addMeeting()">Send Meeting Request</button>
    </div>
    <br />
    <div class="calendar-grid">${calendarDays()}</div>
    <br />
    <div class="panel"><h3>Requests</h3><div class="list">${state.meetings.map(m => `<div class="item"><div><strong>${m.title}</strong><br /><span class="muted">${m.with} - ${m.date}</span></div><div class="actions">${status(m.status)}<button class="success-btn" onclick="updateMeeting(${m.id},'confirmed')">Accept</button><button class="danger-btn" onclick="updateMeeting(${m.id},'declined')">Decline</button></div></div>`).join("")}</div></div>
  `;
}

function calendarDays() {
  return Array.from({ length: 30 }, (_, i) => {
    const day = i + 1;
    const date = `2026-04-${String(day).padStart(2, "0")}`;
    const events = state.meetings.filter(m => m.date === date).map(m => `<div class="event">${m.title}</div>`).join("");
    return `<div class="day"><strong>${day}</strong>${events}</div>`;
  }).join("");
}

function addMeeting() {
  const title = document.getElementById("meetingTitle").value;
  const withName = document.getElementById("meetingWith").value;
  const date = document.getElementById("meetingDate").value;
  if (!title || !withName || !date) return alert("Fill title, person and date.");
  state.meetings.push({ id: Date.now(), title, with: withName, date, time: "10:00", status: "pending" });
  render();
}

function updateMeeting(id, statusValue) {
  state.meetings = state.meetings.map(m => m.id === id ? { ...m, status: statusValue } : m);
  render();
}

function videoMarkup() {
  return `
    <div class="grid-2">
      <div>
        <div class="video-stage ${state.call.video ? "" : "video-off"}">${state.call.screen ? `<div class="screen-share"><h2>Screen Sharing Active</h2></div>` : `<div class="video-avatar">${state.call.active ? "You" : "N"}</div>`}</div>
        <br />
        <div class="panel actions" style="justify-content:center">
          <button class="${state.call.active ? "danger-btn" : "success-btn"}" onclick="toggleCall()">${state.call.active ? "End Call" : "Start Call"}</button>
          <button class="ghost-btn" onclick="state.call.video=!state.call.video;render()">${state.call.video ? "Video On" : "Video Off"}</button>
          <button class="ghost-btn" onclick="state.call.audio=!state.call.audio;render()">${state.call.audio ? "Audio On" : "Muted"}</button>
          <button class="ghost-btn" onclick="state.call.screen=!state.call.screen;render()">Screen Share</button>
        </div>
      </div>
      <div class="panel"><h3>Participants</h3><div class="list"><div class="item">You ${status(state.call.active ? "confirmed" : "pending")}</div><div class="item">Sarah Chen ${status("confirmed")}</div><div class="item">Marcus Rivera ${status("confirmed")}</div></div></div>
    </div>
  `;
}

function toggleCall() {
  state.call.active = !state.call.active;
  if (!state.call.active) state.call.screen = false;
  render();
}

function documentsMarkup() {
  return `
    <div class="panel">
      <h3>Upload Document</h3>
      <div class="grid-3"><div class="field"><label>Title</label><input id="docTitle" /></div><div class="field"><label>Type</label><select id="docType"><option>PDF</option><option>DOCX</option><option>DOC</option></select></div><div class="field"><label>Status</label><select id="docStatus"><option value="draft">Draft</option><option value="review">In Review</option></select></div></div>
      <button class="primary-btn" onclick="addDoc()">Upload</button>
    </div>
    <br />
    <div class="panel"><h3>Documents</h3><div class="list">${state.docs.map(d => `<div class="item"><div><strong>${d.title}</strong><br /><span class="muted">${d.type}</span></div><div class="actions">${status(d.status)}<button class="ghost-btn" onclick="previewDoc(${d.id})">Preview</button>${d.signed ? "" : `<button class="primary-btn" onclick="signDoc(${d.id})">E-Sign</button>`}</div></div>`).join("")}</div></div>
  `;
}

function addDoc() {
  const title = document.getElementById("docTitle").value;
  if (!title) return alert("Enter document title.");
  state.docs.unshift({ id: Date.now(), title, type: document.getElementById("docType").value, status: document.getElementById("docStatus").value, signed: false });
  render();
}

function previewDoc(id) {
  const d = state.docs.find(doc => doc.id === id);
  showModal(`<h2>${d.title}</h2><p class="muted">${d.type} document preview</p><p>This is a mock preview for contracts, NDAs, and deal documents. Parties can review status, signatures, and completion progress.</p>${status(d.status)}<br /><br /><button class="ghost-btn" onclick="closeModal()">Close</button>`);
}

function signDoc(id) {
  showModal(`<h2>E-Signature</h2><p class="muted">Draw your signature below.</p><canvas class="signature-pad" id="sigPad"></canvas><br /><br /><button class="ghost-btn" onclick="clearSig()">Clear</button> <button class="primary-btn" onclick="completeSign(${id})">Apply Signature</button>`);
}

function attachSignatureEvents() {
  const canvas = document.getElementById("sigPad");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  canvas.width = canvas.clientWidth;
  canvas.height = canvas.clientHeight;
  let drawing = false;
  const point = e => {
    const rect = canvas.getBoundingClientRect();
    const t = e.touches ? e.touches[0] : e;
    return { x: t.clientX - rect.left, y: t.clientY - rect.top };
  };
  const start = e => { drawing = true; const p = point(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); };
  const move = e => { if (!drawing) return; e.preventDefault(); const p = point(e); ctx.lineWidth = 3; ctx.lineCap = "round"; ctx.strokeStyle = "#2563eb"; ctx.lineTo(p.x, p.y); ctx.stroke(); };
  const stop = () => drawing = false;
  canvas.onmousedown = start; canvas.onmousemove = move; canvas.onmouseup = stop; canvas.onmouseleave = stop;
  canvas.ontouchstart = start; canvas.ontouchmove = move; canvas.ontouchend = stop;
}

function clearSig() {
  const canvas = document.getElementById("sigPad");
  canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);
}

function completeSign(id) {
  state.docs = state.docs.map(d => d.id === id ? { ...d, status: "signed", signed: true } : d);
  closeModal();
  render();
}

function paymentsMarkup() {
  return `
    <div class="panel" style="background:linear-gradient(135deg,#0f172a,#1e293b);color:white"><span style="color:#cbd5e1">Wallet Balance</span><h1>${money(state.user.wallet)}</h1></div>
    <br />
    <div class="tabbar role-switch"><button onclick="paymentAction('deposit')">Deposit</button><button onclick="paymentAction('withdraw')">Withdraw</button><button onclick="paymentAction('transfer')">Transfer</button><button onclick="fundingModal()">Fund Deal</button></div>
    <br />
    <div class="table-wrap"><h3>Transaction History</h3><table><thead><tr><th>Type</th><th>Amount</th><th>Sender</th><th>Receiver</th><th>Status</th><th>Date</th></tr></thead><tbody>${state.txs.map(t => `<tr><td>${t.type}</td><td>${money(t.amount)}</td><td>${t.sender}</td><td>${t.receiver}</td><td>${status(t.status)}</td><td>${t.date}</td></tr>`).join("")}</tbody></table></div>
  `;
}

function paymentAction(type) {
  showModal(`<h2>${type}</h2><div class="field"><label>Amount</label><input id="payAmount" type="number" /></div><div class="field"><label>${type === "transfer" ? "Recipient" : "Account"}</label><input id="payTarget" value="${type === "deposit" ? "Bank Transfer" : type === "withdraw" ? "Bank Account" : ""}" /></div><button class="primary-btn" onclick="completePayment('${type}')">Confirm</button>`);
}

function completePayment(type) {
  const amount = Number(document.getElementById("payAmount").value);
  const target = document.getElementById("payTarget").value || "Recipient";
  if (!amount) return alert("Enter amount.");
  if (type === "deposit") state.user.wallet += amount;
  if (type === "withdraw" || type === "transfer") state.user.wallet -= amount;
  state.txs.unshift({ id: Date.now(), type, amount, sender: type === "deposit" ? target : "You", receiver: type === "deposit" ? "You" : target, status: "completed", date: new Date().toISOString().slice(0, 10) });
  closeModal(); render();
}

function fundingModal() {
  showModal(`<h2>Fund Deal</h2><div class="field"><label>Deal</label><select id="dealId">${state.deals.map(d => `<option value="${d.id}">${d.title}</option>`).join("")}</select></div><div class="field"><label>Amount</label><input id="fundAmount" type="number" /></div><button class="primary-btn" onclick="completeFunding()">Fund Deal</button>`);
}

function completeFunding() {
  const dealId = Number(document.getElementById("dealId").value);
  const amount = Number(document.getElementById("fundAmount").value);
  const deal = state.deals.find(d => d.id === dealId);
  if (!amount) return alert("Enter amount.");
  deal.raised += amount;
  state.user.wallet -= amount;
  state.txs.unshift({ id: Date.now(), type: "funding", amount, sender: "You", receiver: deal.founder, status: "completed", date: new Date().toISOString().slice(0, 10) });
  closeModal(); render();
}

function securityMarkup() {
  return `
    <div class="grid-3"><div class="stat"><span class="muted">Role</span><strong>${state.role}</strong></div><div class="stat"><span class="muted">2FA</span><strong>Enabled</strong></div><div class="stat"><span class="muted">Access</span><strong>Role Based</strong></div></div>
    <br />
    <div class="grid-2">
      <div class="panel"><h3>Password Strength Meter</h3><div class="field"><label>New Password</label><input type="password" oninput="updateStrength(this.value)" /></div><div class="strength"><span id="strengthBar"></span></div><p id="strengthText" class="muted">Password strength</p><button class="primary-btn">Update Password</button></div>
      <div class="panel"><h3>Multi-Step Login & 2FA</h3><p class="muted">This static build includes a mock OTP login step. Use <strong>123456</strong> during sign in.</p><p>${status("confirmed")} Two-factor authentication enabled.</p></div>
    </div>
  `;
}

function tourMarkup() {
  return `<div class="tour"><strong>Guided Walkthrough</strong><p>Use the sidebar to explore meetings, video calls, document chamber, payments, and security modules.</p><button class="primary-btn" onclick="state.tour=false;render()">Finish Tour</button></div>`;
}

function showModal(html) {
  const div = document.createElement("div");
  div.className = "modal-backdrop";
  div.id = "modalRoot";
  div.innerHTML = `<div class="modal">${html}</div>`;
  document.body.appendChild(div);
  attachSignatureEvents();
}

function closeModal() {
  document.getElementById("modalRoot")?.remove();
}

render();