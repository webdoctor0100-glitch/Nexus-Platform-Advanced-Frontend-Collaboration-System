import { useState } from "react";
import { useStore } from "@/store/useStore";
import {
  Shield,
  Key,
  Smartphone,
  Eye,
  EyeOff,
  Check,
  X,
  Lock,
  UserCheck,
  Building2,
  User,
  Activity,
} from "lucide-react";

export default function SecurityPage() {
  const { user } = useStore();

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [passwordChanged, setPasswordChanged] = useState(false);

  const evaluatePassword = (p: string) => {
    let score = 0;
    if (p.length >= 8) score++;
    if (/[A-Z]/.test(p)) score++;
    if (/[0-9]/.test(p)) score++;
    if (/[^A-Za-z0-9]/.test(p)) score++;
    setPasswordStrength(score);
    return score;
  };

  const handlePasswordChange = (val: string) => {
    setNewPassword(val);
    evaluatePassword(val);
  };

  const handleChangePassword = () => {
    if (newPassword !== confirmPassword) return;
    if (passwordStrength < 3) return;
    setPasswordChanged(true);
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
    setPasswordStrength(0);
    setTimeout(() => setPasswordChanged(false), 3000);
  };

  const strengthLabels = ["Weak", "Fair", "Good", "Strong", "Very Strong"];
  const strengthColors = [
    "bg-nexus-rose-500",
    "bg-nexus-amber-500",
    "bg-nexus-amber-500",
    "bg-nexus-emerald-500",
    "bg-nexus-emerald-600",
  ];
  const strengthTextColors = [
    "text-nexus-rose-500",
    "text-nexus-amber-500",
    "text-nexus-amber-500",
    "text-nexus-emerald-500",
    "text-nexus-emerald-600",
  ];

  const securityChecks = [
    {
      label: "Two-Factor Authentication",
      status: "enabled",
      icon: Smartphone,
      description: "OTP via authenticator app",
    },
    {
      label: "Password",
      status: passwordStrength >= 3 ? "strong" : "needs_attention",
      icon: Key,
      description:
        passwordStrength >= 3
          ? "Password meets security requirements"
          : "Update password for better security",
    },
    {
      label: "Login Notifications",
      status: "enabled",
      icon: Activity,
      description: "Email alerts for new logins",
    },
  ];

  return (
    <div className="p-4 lg:p-6 space-y-6 animate-fade-in-up" id="security-page">
      <h2 className="text-2xl font-bold text-nexus-dark-800">
        Security & Access Control
      </h2>

      {/* Role Badge */}
      <div className="bg-white rounded-xl border border-nexus-dark-100 p-5">
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-xl bg-gradient-to-br from-nexus-purple-50 to-nexus-blue-50">
            {user?.role === "investor" ? (
              <Building2 className="h-6 w-6 text-nexus-purple-500" />
            ) : (
              <User className="h-6 w-6 text-nexus-blue-500" />
            )}
          </div>
          <div>
            <p className="text-sm text-nexus-dark-500">Account Role</p>
            <p className="text-lg font-bold text-nexus-dark-800 capitalize">
              {user?.role}
            </p>
          </div>
          <div className="ml-auto">
            <span
              className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full ${
                user?.role === "investor"
                  ? "bg-nexus-purple-50 text-nexus-purple-600"
                  : "bg-nexus-blue-50 text-nexus-blue-600"
              }`}
            >
              {user?.role === "investor" ? (
                <Building2 className="h-3.5 w-3.5" />
              ) : (
                <User className="h-3.5 w-3.5" />
              )}
              {user?.role === "investor" ? "Investor Dashboard" : "Entrepreneur Dashboard"}
            </span>
          </div>
        </div>
      </div>

      {/* Security Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {securityChecks.map((check) => (
          <div
            key={check.label}
            className="bg-white rounded-xl border border-nexus-dark-100 p-5"
          >
            <div className="flex items-center gap-3 mb-3">
              <div
                className={`p-2 rounded-lg ${
                  check.status === "enabled" || check.status === "strong"
                    ? "bg-emerald-50"
                    : "bg-nexus-amber-50"
                }`}
              >
                <check.icon
                  className={`h-5 w-5 ${
                    check.status === "enabled" || check.status === "strong"
                      ? "text-emerald-500"
                      : "text-nexus-amber-500"
                  }`}
                />
              </div>
              <div>
                <h4 className="font-semibold text-sm text-nexus-dark-700">
                  {check.label}
                </h4>
                <p className="text-xs text-nexus-dark-400">
                  {check.description}
                </p>
              </div>
            </div>
            <span
              className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full ${
                check.status === "enabled" || check.status === "strong"
                  ? "bg-emerald-50 text-emerald-600"
                  : "bg-nexus-amber-50 text-nexus-amber-600"
              }`}
            >
              {check.status === "enabled"
                ? "Enabled"
                : check.status === "strong"
                ? "Strong"
                : "Needs Attention"}
            </span>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Password Change */}
        <div className="bg-white rounded-xl border border-nexus-dark-100 p-5">
          <h3 className="font-semibold text-nexus-dark-700 mb-4 flex items-center gap-2">
            <Lock className="h-4 w-4 text-nexus-dark-500" />
            Change Password
          </h3>

          {passwordChanged && (
            <div className="mb-4 p-3 bg-emerald-50 text-emerald-600 rounded-xl text-sm font-medium flex items-center gap-2">
              <Check className="h-4 w-4" />
              Password changed successfully!
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                Current Password
              </label>
              <div className="relative">
                <input
                  type={showCurrent ? "text" : "password"}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm pr-10"
                  placeholder="••••••••"
                />
                <button
                  onClick={() => setShowCurrent(!showCurrent)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-nexus-dark-400"
                >
                  {showCurrent ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                New Password
              </label>
              <div className="relative">
                <input
                  type={showNew ? "text" : "password"}
                  value={newPassword}
                  onChange={(e) => handlePasswordChange(e.target.value)}
                  className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm pr-10"
                  placeholder="••••••••"
                />
                <button
                  onClick={() => setShowNew(!showNew)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-nexus-dark-400"
                >
                  {showNew ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>

              {newPassword && (
                <div className="mt-2">
                  <div className="flex gap-1 mb-1">
                    {[1, 2, 3, 4].map((level) => (
                      <div
                        key={level}
                        className={`h-1.5 flex-1 rounded-full transition-colors ${
                          level <= passwordStrength
                            ? strengthColors[passwordStrength]
                            : "bg-nexus-dark-200"
                        }`}
                      />
                    ))}
                  </div>
                  <p
                    className={`text-xs font-medium ${
                      passwordStrength > 0
                        ? strengthTextColors[passwordStrength - 1]
                        : "text-nexus-dark-400"
                    }`}
                  >
                    {passwordStrength > 0
                      ? strengthLabels[passwordStrength - 1]
                      : "Password strength"}
                  </p>
                  <ul className="mt-2 space-y-1">
                    {[
                      { check: newPassword.length >= 8, text: "At least 8 characters" },
                      { check: /[A-Z]/.test(newPassword), text: "Uppercase letter" },
                      { check: /[0-9]/.test(newPassword), text: "Number" },
                      {
                        check: /[^A-Za-z0-9]/.test(newPassword),
                        text: "Special character",
                      },
                    ].map((req, i) => (
                      <li
                        key={i}
                        className="flex items-center gap-2 text-xs"
                      >
                        {req.check ? (
                          <Check className="h-3 w-3 text-emerald-500" />
                        ) : (
                          <X className="h-3 w-3 text-nexus-dark-300" />
                        )}
                        <span
                          className={
                            req.check
                              ? "text-emerald-600"
                              : "text-nexus-dark-400"
                          }
                        >
                          {req.text}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                Confirm New Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                placeholder="••••••••"
              />
              {confirmPassword && newPassword !== confirmPassword && (
                <p className="text-xs text-nexus-rose-500 mt-1">
                  Passwords don't match
                </p>
              )}
            </div>

            <button
              onClick={handleChangePassword}
              disabled={
                !currentPassword ||
                !newPassword ||
                newPassword !== confirmPassword ||
                passwordStrength < 3
              }
              className="w-full py-2.5 bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-600 text-white rounded-xl text-sm font-semibold hover:from-nexus-blue-600 hover:to-nexus-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              Update Password
            </button>
          </div>
        </div>

        {/* 2FA Section */}
        <div className="bg-white rounded-xl border border-nexus-dark-100 p-5">
          <h3 className="font-semibold text-nexus-dark-700 mb-4 flex items-center gap-2">
            <Smartphone className="h-4 w-4 text-nexus-dark-500" />
            Two-Factor Authentication
          </h3>

          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center">
                <Shield className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <p className="font-semibold text-emerald-700 text-sm">
                  2FA is Active
                </p>
                <p className="text-xs text-emerald-600">
                  Your account is protected with OTP-based authentication
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3 text-sm">
            <p className="text-nexus-dark-600">
              Two-factor authentication adds an extra layer of security to your
              account. When logging in, you'll need to enter a 6-digit code from
              your authenticator app.
            </p>

            <div className="bg-nexus-dark-50 rounded-xl p-4">
              <h4 className="font-semibold text-nexus-dark-700 mb-2">
                Demo OTP
              </h4>
              <p className="text-nexus-dark-500 text-xs mb-2">
                For demo purposes, use the following OTP when prompted:
              </p>
              <code className="block text-center text-lg font-bold text-nexus-blue-600 bg-white rounded-lg py-2 border border-nexus-dark-200">
                123456
              </code>
            </div>

            <div className="flex items-center gap-3 p-3 bg-nexus-dark-50 rounded-xl">
              <UserCheck className="h-5 w-5 text-nexus-dark-400" />
              <p className="text-xs text-nexus-dark-500">
                Last 2FA verification: Today at login
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Role-based UI Demo */}
      <div className="bg-white rounded-xl border border-nexus-dark-100 p-5">
        <h3 className="font-semibold text-nexus-dark-700 mb-4">
          Role-Based Access
        </h3>
        <p className="text-sm text-nexus-dark-500 mb-4">
          The interface adapts based on your role. Here's what you can access:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="border border-nexus-purple-200 bg-nexus-purple-50 rounded-xl p-4">
            <Building2 className="h-5 w-5 text-nexus-purple-500 mb-2" />
            <h4 className="font-semibold text-nexus-purple-700 mb-1">
              Investor Features
            </h4>
            <ul className="text-xs text-nexus-purple-600 space-y-1">
              <li>• Browse & fund deals</li>
              <li>• View portfolio investments</li>
              <li>• Schedule meetings with founders</li>
              <li>• Sign investment agreements</li>
              <li>• Transfer funds</li>
            </ul>
          </div>
          <div className="border border-nexus-blue-200 bg-nexus-blue-50 rounded-xl p-4">
            <User className="h-5 w-5 text-nexus-blue-500 mb-2" />
            <h4 className="font-semibold text-nexus-blue-700 mb-1">
              Entrepreneur Features
            </h4>
            <ul className="text-xs text-nexus-blue-600 space-y-1">
              <li>• Create funding proposals</li>
              <li>• Track fundraising progress</li>
              <li>• Meet with investors</li>
              <li>• Upload & sign documents</li>
              <li>• Receive investment payments</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
