import { useState, useRef, useEffect } from "react";
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  MonitorUp,
  PhoneOff,
  Phone,
  Users,
  Settings,
} from "lucide-react";

export default function VideoCallPage() {
  const [isInCall, setIsInCall] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isAudioOn, setIsAudioOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [participants] = useState([
    { id: "1", name: "You", isHost: true, videoOn: true },
    { id: "2", name: "Sarah Chen", isHost: false, videoOn: true },
    { id: "3", name: "Marcus Rivera", isHost: false, videoOn: true },
  ]);

  const videoRef = useRef<HTMLVideoElement>(null);
  const timerRef = useRef<ReturnType<typeof setInterval>>(undefined);

  useEffect(() => {
    if (isInCall) {
      timerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setCallDuration(0);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isInCall]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs
      .toString()
      .padStart(2, "0")}`;
  };

  // Mock camera simulation
  useEffect(() => {
    if (isInCall && isVideoOn && videoRef.current) {
      // Create a canvas-based simulated video feed
      const canvas = document.createElement("canvas");
      canvas.width = 640;
      canvas.height = 480;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        let hue = 200;
        const animate = () => {
          hue = (hue + 0.3) % 360;
          const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
          gradient.addColorStop(0, `hsl(${hue}, 60%, 20%)`);
          gradient.addColorStop(0.5, `hsl(${(hue + 30) % 360}, 50%, 15%)`);
          gradient.addColorStop(1, `hsl(${(hue + 60) % 360}, 60%, 20%)`);
          ctx.fillStyle = gradient;
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          // Simulated avatar circle
          ctx.beginPath();
          ctx.arc(canvas.width / 2, 180, 70, 0, Math.PI * 2);
          ctx.fillStyle = `hsl(${(hue + 180) % 360}, 60%, 60%)`;
          ctx.fill();
          ctx.fillStyle = "white";
          ctx.font = "bold 40px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("You", canvas.width / 2, 200);

          // Background decorative dots
          for (let i = 0; i < 20; i++) {
            const x = (Math.sin(hue * 0.01 + i) * 0.5 + 0.5) * canvas.width;
            const y = (Math.cos(hue * 0.02 + i) * 0.5 + 0.5) * canvas.height;
            ctx.beginPath();
            ctx.arc(x, y, 3 + Math.random() * 5, 0, Math.PI * 2);
            ctx.fillStyle = `hsla(${hue}, 70%, 80%, ${0.3 + Math.random() * 0.3})`;
            ctx.fill();
          }

          // Simulated noise
          if (isInCall && videoRef.current) {
            const stream = canvas.captureStream(30);
            videoRef.current.srcObject = stream;
          }

          if (isInCall) requestAnimationFrame(animate);
        };
        animate();
      }
    } else if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, [isInCall, isVideoOn]);

  const startCall = () => setIsInCall(true);
  const endCall = () => setIsInCall(false);

  return (
    <div className="p-4 lg:p-6 space-y-6 animate-fade-in-up" id="video-call-page">
      <h2 className="text-2xl font-bold text-nexus-dark-800">Video Call</h2>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Video Area */}
        <div className="lg:col-span-3">
          <div className="bg-nexus-dark-900 rounded-2xl overflow-hidden relative aspect-video">
            {isInCall ? (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  muted
                  playsInline
                  className="w-full h-full object-cover"
                />
                {!isVideoOn && (
                  <div className="absolute inset-0 flex items-center justify-center bg-nexus-dark-800">
                    <div className="text-center">
                      <div className="h-24 w-24 rounded-full bg-gradient-to-br from-nexus-purple-400 to-nexus-blue-500 flex items-center justify-center mx-auto mb-4">
                        <Users className="h-12 w-12 text-white" />
                      </div>
                      <p className="text-white font-medium">Camera Off</p>
                    </div>
                  </div>
                )}
                {isScreenSharing && (
                  <div className="absolute inset-0 bg-nexus-dark-900 flex items-center justify-center">
                    <div className="text-center text-white">
                      <MonitorUp className="h-16 w-16 mx-auto mb-4 text-nexus-blue-400" />
                      <p className="text-lg font-semibold">Sharing Screen</p>
                      <p className="text-sm text-nexus-dark-400">
                        Your screen is being shared
                      </p>
                    </div>
                  </div>
                )}
                {/* Call timer */}
                <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm rounded-lg px-3 py-1.5">
                  <span className="text-white font-mono text-sm">
                    {formatTime(callDuration)}
                  </span>
                </div>
                {/* Participants overlay */}
                <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm rounded-lg px-3 py-1.5 flex items-center gap-2">
                  <Users className="h-3.5 w-3.5 text-white" />
                  <span className="text-white text-sm">
                    {participants.length}
                  </span>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <div className="h-20 w-20 rounded-full bg-gradient-to-br from-nexus-blue-500/30 to-nexus-purple-600/30 flex items-center justify-center mx-auto mb-4">
                    <Video className="h-10 w-10 text-nexus-blue-400" />
                  </div>
                  <p className="text-nexus-dark-400 text-lg">
                    Ready to start a call?
                  </p>
                  <p className="text-nexus-dark-500 text-sm mt-1">
                    Connect with investors and entrepreneurs via secure video
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Call Controls */}
          <div className="flex items-center justify-center gap-4 mt-4 p-4 bg-white rounded-2xl border border-nexus-dark-100">
            <button
              onClick={() => setIsAudioOn(!isAudioOn)}
              disabled={!isInCall}
              className={`p-3.5 rounded-xl transition-all ${
                isAudioOn
                  ? "bg-nexus-dark-100 text-nexus-dark-600 hover:bg-nexus-dark-200"
                  : "bg-nexus-rose-50 text-nexus-rose-500 hover:bg-nexus-rose-100"
              } disabled:opacity-40 disabled:cursor-not-allowed`}
              title={isAudioOn ? "Mute" : "Unmute"}
            >
              {isAudioOn ? (
                <Mic className="h-5 w-5" />
              ) : (
                <MicOff className="h-5 w-5" />
              )}
            </button>

            <button
              onClick={() => setIsVideoOn(!isVideoOn)}
              disabled={!isInCall}
              className={`p-3.5 rounded-xl transition-all ${
                isVideoOn
                  ? "bg-nexus-dark-100 text-nexus-dark-600 hover:bg-nexus-dark-200"
                  : "bg-nexus-rose-50 text-nexus-rose-500 hover:bg-nexus-rose-100"
              } disabled:opacity-40 disabled:cursor-not-allowed`}
              title={isVideoOn ? "Turn off camera" : "Turn on camera"}
            >
              {isVideoOn ? (
                <Video className="h-5 w-5" />
              ) : (
                <VideoOff className="h-5 w-5" />
              )}
            </button>

            {isInCall ? (
              <button
                onClick={endCall}
                className="p-3.5 rounded-xl bg-nexus-rose-500 text-white hover:bg-nexus-rose-600 transition-all shadow-lg shadow-nexus-rose-500/30"
                title="End Call"
              >
                <PhoneOff className="h-5 w-5" />
              </button>
            ) : (
              <button
                onClick={startCall}
                className="p-3.5 rounded-xl bg-emerald-500 text-white hover:bg-emerald-600 transition-all shadow-lg shadow-emerald-500/30"
                title="Start Call"
              >
                <Phone className="h-5 w-5" />
              </button>
            )}

            <button
              onClick={() => setIsScreenSharing(!isScreenSharing)}
              disabled={!isInCall}
              className={`p-3.5 rounded-xl transition-all ${
                isScreenSharing
                  ? "bg-nexus-blue-50 text-nexus-blue-600"
                  : "bg-nexus-dark-100 text-nexus-dark-600 hover:bg-nexus-dark-200"
              } disabled:opacity-40 disabled:cursor-not-allowed`}
              title="Share Screen"
            >
              <MonitorUp className="h-5 w-5" />
            </button>

            <button
              disabled={!isInCall}
              className="p-3.5 rounded-xl bg-nexus-dark-100 text-nexus-dark-600 hover:bg-nexus-dark-200 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
              title="Settings"
            >
              <Settings className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Participants Sidebar */}
        <div className="bg-white rounded-2xl border border-nexus-dark-100 p-5">
          <h3 className="font-semibold text-nexus-dark-700 mb-4 flex items-center gap-2">
            <Users className="h-4 w-4" />
            Participants ({participants.length})
          </h3>
          <div className="space-y-3">
            {participants.map((p) => (
              <div
                key={p.id}
                className="flex items-center gap-3 p-3 rounded-xl bg-nexus-dark-50"
              >
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-nexus-purple-400 to-nexus-blue-500 flex items-center justify-center text-white text-sm font-bold shrink-0">
                  {p.name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-nexus-dark-700 truncate">
                    {p.name}
                    {p.isHost && (
                      <span className="text-xs text-nexus-blue-500 ml-1">
                        (Host)
                      </span>
                    )}
                  </p>
                  <div className="flex items-center gap-1">
                    {p.videoOn ? (
                      <Video className="h-3 w-3 text-emerald-500" />
                    ) : (
                      <VideoOff className="h-3 w-3 text-nexus-dark-400" />
                    )}
                    <span className="text-xs text-nexus-dark-400">
                      {p.videoOn ? "Video on" : "Video off"}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Join Info */}
          {!isInCall && (
            <div className="mt-6 p-4 bg-nexus-blue-50 rounded-xl border border-nexus-blue-100">
              <p className="text-sm font-semibold text-nexus-blue-700 mb-1">
                Meeting Room
              </p>
              <p className="text-xs text-nexus-blue-600 font-mono">
                nexus-call/room-42a7
              </p>
              <p className="text-xs text-nexus-blue-500 mt-2">
                Click "Start Call" to begin a simulated WebRTC session.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
