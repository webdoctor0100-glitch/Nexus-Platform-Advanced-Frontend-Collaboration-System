import { useState } from "react";
import { useStore } from "@/store/useStore";
import { Zap, ArrowRight, Building2, User, Eye, EyeOff, Shield } from "lucide-react";
import type { UserRole } from "@/types";

export default function LoginPage() {
  const { login, verifyOTP, loginStep, setCurrentPage } =
    useStore();

  const [email, setEmail] = useState("alex@investor.com");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [role, setRole] = useState<UserRole>("investor");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [otpError, setOtpError] = useState("");
  const [passwordStrength, setPasswordStrength] = useState(0);

  const evaluatePassword = (p: string) => {
    let score = 0;
    if (p.length >= 8) score++;
    if (/[A-Z]/.test(p)) score++;
    if (/[0-9]/.test(p)) score++;
    if (/[^A-Za-z0-9]/.test(p)) score++;
    setPasswordStrength(score);
    return score;
  };

  const handlePasswordChange = (val: string) => {
    setPassword(val);
    evaluatePassword(val);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login(email, password, role);
  };

  const handleOTPChange = (index: number, value: string) => {
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    setOtpError("");

    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }

    if (newOtp.every((d) => d !== "")) {
      const otpStr = newOtp.join("");
      if (verifyOTP(otpStr)) {
        setTimeout(() => setCurrentPage("dashboard"), 500);
      } else {
        setOtpError("Invalid OTP. Use 123456 for demo.");
        setOtp(["", "", "", "", "", ""]);
        document.getElementById("otp-0")?.focus();
      }
    }
  };

  const strengthLabels = ["Weak", "Fair", "Good", "Strong", "Very Strong"];
  const strengthColors = [
    "bg-nexus-rose-500",
    "bg-nexus-amber-500",
    "bg-nexus-amber-500",
    "bg-nexus-emerald-500",
    "bg-nexus-emerald-600",
  ];

  if (loginStep === 2) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-nexus-dark-50 via-white to-nexus-blue-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md animate-fade-in-up">
          <div className="bg-white rounded-2xl shadow-xl shadow-nexus-dark-200/50 p-8">
            <div className="text-center mb-8">
              <div className="inline-flex h-14 w-14 rounded-2xl bg-gradient-to-br from-nexus-blue-500 to-nexus-purple-600 items-center justify-center mb-4">
                <Shield className="h-7 w-7 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-nexus-dark-800">
                Two-Factor Authentication
              </h2>
              <p className="text-nexus-dark-500 mt-2">
                Enter the 6-digit code sent to your device
              </p>
            </div>

            <div className="flex justify-center gap-2 mb-6">
              {otp.map((digit, i) => (
                <input
                  key={i}
                  id={`otp-${i}`}
                  type="text"
                  inputMode="numeric"
                  value={digit}
                  onChange={(e) => handleOTPChange(i, e.target.value)}
                  className="w-12 h-14 text-center text-xl font-bold border-2 border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 focus:outline-none text-nexus-dark-800"
                  maxLength={1}
                />
              ))}
            </div>

            {otpError && (
              <div className="bg-nexus-rose-50 text-nexus-rose-600 text-sm rounded-lg px-4 py-3 mb-4 text-center">
                {otpError}
              </div>
            )}

            <p className="text-center text-sm text-nexus-dark-400">
              Demo OTP: <span className="font-mono font-bold text-nexus-blue-600">123456</span>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-nexus-dark-50 via-white to-nexus-blue-50 flex items-center justify-center p-4">
      <div className="w-full max-w-lg animate-fade-in-up">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex h-14 w-14 rounded-2xl bg-gradient-to-br from-nexus-blue-500 to-nexus-purple-600 items-center justify-center mb-4">
            <Zap className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-nexus-dark-800">Nexus</h1>
          <p className="text-nexus-dark-500 mt-1">
            Investor & Entrepreneur Collaboration Platform
          </p>
        </div>

        {/* Role Selector */}
        <div className="bg-white rounded-2xl shadow-xl shadow-nexus-dark-200/50 p-1 mb-4 flex">
          {(["investor", "entrepreneur"] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRole(r)}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-all ${
                role === r
                  ? "bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-600 text-white shadow-md"
                  : "text-nexus-dark-500 hover:text-nexus-dark-700"
              }`}
            >
              {r === "investor" ? (
                <Building2 className="h-4 w-4" />
              ) : (
                <User className="h-4 w-4" />
              )}
              {r === "investor" ? "Investor" : "Entrepreneur"}
            </button>
          ))}
        </div>

        {/* Login Form */}
        <div className="bg-white rounded-2xl shadow-xl shadow-nexus-dark-200/50 p-8">
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-nexus-dark-700 mb-1.5">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 focus:ring-2 focus:ring-nexus-blue-500/20 outline-none text-nexus-dark-800 text-sm transition-all"
                placeholder="you@example.com"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-nexus-dark-700 mb-1.5">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => handlePasswordChange(e.target.value)}
                  className="w-full px-4 py-3 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 focus:ring-2 focus:ring-nexus-blue-500/20 outline-none text-nexus-dark-800 text-sm transition-all pr-11"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-nexus-dark-400 hover:text-nexus-dark-600"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>

              {/* Password strength meter */}
              {password && (
                <div className="mt-2">
                  <div className="flex gap-1 mb-1">
                    {[1, 2, 3, 4].map((level) => (
                      <div
                        key={level}
                        className={`h-1.5 flex-1 rounded-full transition-colors ${
                          level <= passwordStrength
                            ? strengthColors[passwordStrength]
                            : "bg-nexus-dark-200"
                        }`}
                      />
                    ))}
                  </div>
                  <p
                    className="text-xs font-medium"
                    style={{
                      color: passwordStrength > 0 ? undefined : "#94a3b8",
                    }}
                  >
                    {passwordStrength > 0
                      ? strengthLabels[passwordStrength - 1]
                      : "Password strength"}
                  </p>
                </div>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-600 text-white rounded-xl font-semibold hover:from-nexus-blue-600 hover:to-nexus-purple-700 shadow-lg shadow-nexus-blue-500/25 transition-all flex items-center justify-center gap-2"
            >
              Sign In
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-nexus-dark-100">
            <p className="text-xs text-nexus-dark-400 text-center">
              Demo: Use any email/password. OTP will be <span className="font-mono text-nexus-blue-500">123456</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
