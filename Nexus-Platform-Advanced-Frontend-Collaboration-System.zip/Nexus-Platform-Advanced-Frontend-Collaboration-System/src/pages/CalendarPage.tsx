import { useState } from "react";
import { useStore } from "@/store/useStore";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import type { EventClickArg, DateSelectArg } from "@fullcalendar/core";
import {
  Plus,
  X,
  Clock,
  Users,
  Check,
  XCircle,
  Calendar,
  Trash2,
} from "lucide-react";
import type { Meeting } from "@/types";

export default function CalendarPage() {
  const {
    meetings,
    addMeeting,
    updateMeetingStatus,
    deleteMeeting,
  } = useStore();

  const [showNewMeeting, setShowNewMeeting] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split("T")[0]
  );
  const [newMeeting, setNewMeeting] = useState({
    title: "",
    with: "",
    startTime: "09:00",
    endTime: "10:00",
    notes: "",
    withRole: "entrepreneur" as "investor" | "entrepreneur",
  });

  const [viewMode, setViewMode] = useState<"calendar" | "list">("calendar");

  const events = meetings.map((m) => ({
    id: m.id,
    title: m.title,
    start: `${m.date}T${m.startTime}:00`,
    end: `${m.date}T${m.endTime}:00`,
    backgroundColor:
      m.status === "confirmed"
        ? "#10b981"
        : m.status === "declined"
        ? "#f43f5e"
        : "#f59e0b",
    borderColor: "transparent",
    extendedProps: m,
  }));

  const handleDateSelect = (selectInfo: DateSelectArg) => {
    setSelectedDate(selectInfo.startStr.split("T")[0]);
    setShowNewMeeting(true);
  };

  const handleEventClick = (_clickInfo: EventClickArg) => {
    // Could open detail modal - for now just select
  };

  const handleAddMeeting = () => {
    const meeting: Meeting = {
      id: "m" + Date.now(),
      title: newMeeting.title,
      date: selectedDate,
      startTime: newMeeting.startTime,
      endTime: newMeeting.endTime,
      status: "pending",
      with: newMeeting.with,
      withRole: newMeeting.withRole,
      notes: newMeeting.notes,
    };
    addMeeting(meeting);
    setShowNewMeeting(false);
    setNewMeeting({
      title: "",
      with: "",
      startTime: "09:00",
      endTime: "10:00",
      notes: "",
      withRole: "entrepreneur",
    });
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 animate-fade-in-up" id="calendar-page">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-2xl font-bold text-nexus-dark-800">
          Meeting Calendar
        </h2>
        <div className="flex items-center gap-3">
          <div className="flex bg-nexus-dark-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode("calendar")}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                viewMode === "calendar"
                  ? "bg-white text-nexus-dark-800 shadow-sm"
                  : "text-nexus-dark-500 hover:text-nexus-dark-700"
              }`}
            >
              Calendar
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                viewMode === "list"
                  ? "bg-white text-nexus-dark-800 shadow-sm"
                  : "text-nexus-dark-500 hover:text-nexus-dark-700"
              }`}
            >
              List
            </button>
          </div>
          <button
            onClick={() => {
              setSelectedDate(new Date().toISOString().split("T")[0]);
              setShowNewMeeting(true);
            }}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-600 text-white rounded-xl text-sm font-semibold hover:from-nexus-blue-600 hover:to-nexus-purple-700 shadow-lg shadow-nexus-blue-500/25 transition-all"
          >
            <Plus className="h-4 w-4" />
            New Meeting
          </button>
        </div>
      </div>

      {viewMode === "calendar" ? (
        <div className="bg-white rounded-xl border border-nexus-dark-100 p-4">
          <FullCalendar
            plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
            initialView="dayGridMonth"
            headerToolbar={{
              left: "prev,next today",
              center: "title",
              right: "dayGridMonth,timeGridWeek",
            }}
            events={events}
            selectable={true}
            select={handleDateSelect}
            eventClick={handleEventClick}
            height="auto"
            selectMirror={true}
            dayMaxEvents={3}
          />
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-nexus-dark-100 p-5 space-y-3">
          {meetings.length === 0 && (
            <p className="text-center text-nexus-dark-400 py-8">
              No meetings scheduled
            </p>
          )}
          {meetings.map((m) => (
            <div
              key={m.id}
              className="flex items-center justify-between p-4 rounded-xl border border-nexus-dark-100 hover:border-nexus-blue-200 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="p-2.5 rounded-xl bg-nexus-purple-50">
                  <Calendar className="h-5 w-5 text-nexus-purple-500" />
                </div>
                <div>
                  <h4 className="font-semibold text-nexus-dark-800">
                    {m.title}
                  </h4>
                  <div className="flex items-center gap-3 text-sm text-nexus-dark-500 mt-1">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {m.date} • {m.startTime} - {m.endTime}
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3.5 w-3.5" />
                      {m.with}
                    </span>
                  </div>
                  {m.notes && (
                    <p className="text-xs text-nexus-dark-400 mt-1">
                      {m.notes}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                    m.status === "confirmed"
                      ? "bg-emerald-50 text-emerald-600"
                      : m.status === "declined"
                      ? "bg-rose-50 text-rose-600"
                      : "bg-amber-50 text-amber-600"
                  }`}
                >
                  {m.status}
                </span>
                {m.status === "pending" && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => updateMeetingStatus(m.id, "confirmed")}
                      className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors"
                      title="Accept"
                    >
                      <Check className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => updateMeetingStatus(m.id, "declined")}
                      className="p-1.5 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors"
                      title="Decline"
                    >
                      <XCircle className="h-4 w-4" />
                    </button>
                  </div>
                )}
                <button
                  onClick={() => deleteMeeting(m.id)}
                  className="p-1.5 rounded-lg text-nexus-dark-400 hover:bg-nexus-dark-100 hover:text-nexus-rose-500 transition-colors"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* New Meeting Modal */}
      {showNewMeeting && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl animate-fade-in-up">
            <div className="flex items-center justify-between p-5 border-b border-nexus-dark-100">
              <h3 className="font-bold text-lg text-nexus-dark-800">
                Schedule Meeting
              </h3>
              <button
                onClick={() => setShowNewMeeting(false)}
                className="p-1.5 rounded-lg hover:bg-nexus-dark-50 text-nexus-dark-400"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                  Title
                </label>
                <input
                  type="text"
                  value={newMeeting.title}
                  onChange={(e) =>
                    setNewMeeting({ ...newMeeting, title: e.target.value })
                  }
                  className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                  placeholder="Meeting title"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                  With
                </label>
                <input
                  type="text"
                  value={newMeeting.with}
                  onChange={(e) =>
                    setNewMeeting({ ...newMeeting, with: e.target.value })
                  }
                  className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                  placeholder="Person name"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                  Date
                </label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                    Start
                  </label>
                  <input
                    type="time"
                    value={newMeeting.startTime}
                    onChange={(e) =>
                      setNewMeeting({ ...newMeeting, startTime: e.target.value })
                    }
                    className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                    End
                  </label>
                  <input
                    type="time"
                    value={newMeeting.endTime}
                    onChange={(e) =>
                      setNewMeeting({ ...newMeeting, endTime: e.target.value })
                    }
                    className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                  Notes
                </label>
                <textarea
                  value={newMeeting.notes}
                  onChange={(e) =>
                    setNewMeeting({ ...newMeeting, notes: e.target.value })
                  }
                  className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm resize-none h-20"
                  placeholder="Optional notes..."
                />
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-nexus-dark-100">
              <button
                onClick={() => setShowNewMeeting(false)}
                className="flex-1 py-2.5 border border-nexus-dark-200 rounded-xl text-sm font-semibold text-nexus-dark-600 hover:bg-nexus-dark-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddMeeting}
                disabled={!newMeeting.title || !newMeeting.with}
                className="flex-1 py-2.5 bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-600 text-white rounded-xl text-sm font-semibold hover:from-nexus-blue-600 hover:to-nexus-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                Schedule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
