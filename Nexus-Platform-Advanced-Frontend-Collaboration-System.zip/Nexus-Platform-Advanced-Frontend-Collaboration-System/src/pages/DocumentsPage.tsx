import { useState, useRef } from "react";
import { useStore } from "@/store/useStore";
import SignatureCanvas from "react-signature-canvas";
import {
  FileText,
  Upload,
  Pen,
  Eye,
  Download,
  Clock,
  CheckCircle,
  Edit3,
  File,
  X,
  Trash2,
} from "lucide-react";
import type { Document } from "@/types";

const statusConfig: Record<
  Document["status"],
  { label: string; color: string; bg: string; icon: typeof CheckCircle }
> = {
  draft: { label: "Draft", color: "text-nexus-dark-500", bg: "bg-nexus-dark-100", icon: Edit3 },
  in_review: {
    label: "In Review",
    color: "text-nexus-amber-600",
    bg: "bg-nexus-amber-50",
    icon: Clock,
  },
  signed: {
    label: "Signed",
    color: "text-emerald-600",
    bg: "bg-emerald-50",
    icon: CheckCircle,
  },
};

const typeIcons: Record<string, typeof File> = {
  pdf: FileText,
  doc: FileText,
  docx: FileText,
};

export default function DocumentsPage() {
  const {
    documents,
    addDocument,
    updateDocumentStatus,
    signDocument,
    deleteDocument,
  } = useStore();

  const [showUpload, setShowUpload] = useState(false);
  const [showSignModal, setShowSignModal] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState<string | null>(null);
  const signatureRef = useRef<SignatureCanvas>(null);
  const [uploadFile, setUploadFile] = useState<{ title: string; type: Document["type"] }>({ title: "", type: "pdf" });

  const handleUpload = () => {
    if (!uploadFile.title) return;
    const doc: Document = {
      id: "d" + Date.now(),
      title: uploadFile.title,
      type: uploadFile.type,
      size: `${(Math.random() * 3 + 0.5).toFixed(1)} MB`,
      status: "draft",
      uploadedAt: new Date().toISOString().split("T")[0],
      parties: [{ name: "You", signed: false }],
    };
    addDocument(doc);
    setShowUpload(false);
    setUploadFile({ title: "", type: "pdf" });
  };

  const handleSign = (docId: string) => {
    if (signatureRef.current && !signatureRef.current.isEmpty()) {
      const signatureData = signatureRef.current
        .getTrimmedCanvas()
        .toDataURL("image/png");
      signDocument(docId, signatureData);
      setShowSignModal(null);
      signatureRef.current?.clear();
    }
  };

  const handleDelete = (docId: string) => {
    // Using updateDocumentStatus is not delete, so we'll implement via store
    deleteDocument(docId);
  };

  const previewDoc = documents.find((d) => d.id === showPreview);

  return (
    <div className="p-4 lg:p-6 space-y-6 animate-fade-in-up" id="documents-page">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-nexus-dark-800">
            Document Chamber
          </h2>
          <p className="text-nexus-dark-500 text-sm mt-1">
            Manage contracts, NDAs, and investment agreements
          </p>
        </div>
        <button
          onClick={() => setShowUpload(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-600 text-white rounded-xl text-sm font-semibold hover:from-nexus-blue-600 hover:to-nexus-purple-700 shadow-lg shadow-nexus-blue-500/25 transition-all"
        >
          <Upload className="h-4 w-4" />
          Upload Document
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {(["draft", "in_review", "signed"] as const).map((status) => {
          const count = documents.filter((d) => d.status === status).length;
          const cfg = statusConfig[status];
          return (
            <div
              key={status}
              className="bg-white rounded-xl border border-nexus-dark-100 p-4 text-center"
            >
              <cfg.icon className={`h-5 w-5 mx-auto mb-2 ${cfg.color}`} />
              <p className="text-2xl font-bold text-nexus-dark-800">{count}</p>
              <p className={`text-xs font-medium ${cfg.color}`}>{cfg.label}</p>
            </div>
          );
        })}
      </div>

      {/* Document List */}
      <div className="bg-white rounded-xl border border-nexus-dark-100">
        <div className="p-5 border-b border-nexus-dark-100">
          <h3 className="font-semibold text-nexus-dark-700">
            All Documents ({documents.length})
          </h3>
        </div>
        <div className="divide-y divide-nexus-dark-100">
          {documents.length === 0 && (
            <div className="p-8 text-center text-nexus-dark-400">
              <FileText className="h-10 w-10 mx-auto mb-3 text-nexus-dark-300" />
              <p>No documents yet. Upload your first contract.</p>
            </div>
          )}
          {documents.map((doc) => {
            const cfg = statusConfig[doc.status];
            const Icon = typeIcons[doc.type] || File;
            return (
              <div
                key={doc.id}
                className="flex items-center justify-between p-4 hover:bg-nexus-dark-50/50 transition-colors"
              >
                <div className="flex items-center gap-4 flex-1 min-w-0">
                  <div className="p-2.5 rounded-xl bg-nexus-blue-50 shrink-0">
                    <Icon className="h-5 w-5 text-nexus-blue-500" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-semibold text-nexus-dark-800 truncate">
                      {doc.title}
                    </h4>
                    <div className="flex items-center gap-3 text-xs text-nexus-dark-400 mt-1">
                      <span className="uppercase">{doc.type}</span>
                      <span>{doc.size}</span>
                      <span>{doc.uploadedAt}</span>
                      {doc.signedAt && <span>Signed: {doc.signedAt}</span>}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span
                    className={`text-xs font-semibold px-2.5 py-1 rounded-full ${cfg.bg} ${cfg.color}`}
                  >
                    {cfg.label}
                  </span>

                  <button
                    onClick={() => setShowPreview(doc.id)}
                    className="p-2 rounded-lg text-nexus-dark-400 hover:bg-nexus-dark-100 hover:text-nexus-blue-500 transition-colors"
                    title="Preview"
                  >
                    <Eye className="h-4 w-4" />
                  </button>

                  {doc.status !== "signed" && (
                    <button
                      onClick={() => setShowSignModal(doc.id)}
                      className="p-2 rounded-lg text-nexus-dark-400 hover:bg-nexus-purple-50 hover:text-nexus-purple-500 transition-colors"
                      title="Sign"
                    >
                      <Pen className="h-4 w-4" />
                    </button>
                  )}

                  {doc.status === "draft" && (
                    <button
                      onClick={() =>
                        updateDocumentStatus(doc.id, "in_review")
                      }
                      className="p-2 rounded-lg text-nexus-dark-400 hover:bg-nexus-amber-50 hover:text-nexus-amber-500 transition-colors"
                      title="Move to Review"
                    >
                      <Clock className="h-4 w-4" />
                    </button>
                  )}

                  <button
                    onClick={() => handleDelete(doc.id)}
                    className="p-2 rounded-lg text-nexus-dark-400 hover:bg-nexus-rose-50 hover:text-nexus-rose-500 transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Upload Modal */}
      {showUpload && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl animate-fade-in-up">
            <div className="flex items-center justify-between p-5 border-b border-nexus-dark-100">
              <h3 className="font-bold text-lg text-nexus-dark-800">
                Upload Document
              </h3>
              <button
                onClick={() => setShowUpload(false)}
                className="p-1.5 rounded-lg hover:bg-nexus-dark-50 text-nexus-dark-400"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                  Document Title
                </label>
                <input
                  type="text"
                  value={uploadFile.title}
                  onChange={(e) =>
                    setUploadFile({ ...uploadFile, title: e.target.value })
                  }
                  className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                  placeholder="e.g. Series A Investment Agreement"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                  File Type
                </label>
                <select
                  value={uploadFile.type}
                  onChange={(e) =>
                    setUploadFile({
                      ...uploadFile,
                      type: e.target.value as "pdf" | "doc" | "docx" | "other",
                    })
                  }
                  className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                >
                  <option value="pdf">PDF</option>
                  <option value="doc">DOC</option>
                  <option value="docx">DOCX</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div className="border-2 border-dashed border-nexus-dark-200 rounded-xl p-6 text-center hover:border-nexus-blue-400 transition-colors cursor-pointer">
                <Upload className="h-8 w-8 mx-auto mb-2 text-nexus-dark-400" />
                <p className="text-sm text-nexus-dark-500">
                  Drag & drop or click to browse
                </p>
                <p className="text-xs text-nexus-dark-400 mt-1">
                  Supported: PDF, DOC, DOCX (Max 10MB)
                </p>
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-nexus-dark-100">
              <button
                onClick={() => setShowUpload(false)}
                className="flex-1 py-2.5 border border-nexus-dark-200 rounded-xl text-sm font-semibold text-nexus-dark-600 hover:bg-nexus-dark-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleUpload}
                disabled={!uploadFile.title}
                className="flex-1 py-2.5 bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-600 text-white rounded-xl text-sm font-semibold hover:from-nexus-blue-600 hover:to-nexus-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                Upload
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sign Modal */}
      {showSignModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl animate-fade-in-up">
            <div className="flex items-center justify-between p-5 border-b border-nexus-dark-100">
              <h3 className="font-bold text-lg text-nexus-dark-800">
                E-Signature
              </h3>
              <button
                onClick={() => setShowSignModal(null)}
                className="p-1.5 rounded-lg hover:bg-nexus-dark-50 text-nexus-dark-400"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <p className="text-sm text-nexus-dark-500">
                Sign below using your mouse or touchpad:
              </p>
              <div className="border-2 border-nexus-dark-200 rounded-xl overflow-hidden bg-white">
                <SignatureCanvas
                  ref={signatureRef}
                  penColor="#2563eb"
                  canvasProps={{
                    className: "w-full h-48",
                    style: { width: "100%", height: "12rem" },
                  }}
                />
              </div>
              <button
                onClick={() => signatureRef.current?.clear()}
                className="text-sm text-nexus-dark-400 hover:text-nexus-rose-500 transition-colors"
              >
                Clear Signature
              </button>
            </div>
            <div className="flex gap-3 p-5 border-t border-nexus-dark-100">
              <button
                onClick={() => setShowSignModal(null)}
                className="flex-1 py-2.5 border border-nexus-dark-200 rounded-xl text-sm font-semibold text-nexus-dark-600 hover:bg-nexus-dark-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSign(showSignModal)}
                className="flex-1 py-2.5 bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-600 text-white rounded-xl text-sm font-semibold hover:from-nexus-blue-600 hover:to-nexus-purple-700 transition-all"
              >
                Apply Signature
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Preview Modal */}
      {showPreview && previewDoc && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl animate-fade-in-up max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-nexus-dark-100">
              <h3 className="font-bold text-lg text-nexus-dark-800">
                {previewDoc.title}
              </h3>
              <button
                onClick={() => setShowPreview(null)}
                className="p-1.5 rounded-lg hover:bg-nexus-dark-50 text-nexus-dark-400"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 flex-1 overflow-y-auto">
              {/* Mock Document Preview */}
              <div className="border border-nexus-dark-200 rounded-xl p-6 bg-nexus-dark-50">
                <div className="text-center mb-6">
                  <h2 className="text-xl font-bold text-nexus-dark-800">
                    {previewDoc.title}
                  </h2>
                  <p className="text-sm text-nexus-dark-500 mt-1">
                    {previewDoc.type.toUpperCase()} Document • {previewDoc.size}
                  </p>
                </div>

                <div className="space-y-4 text-sm text-nexus-dark-600 leading-relaxed">
                  <p>
                    This agreement is made and entered into as of{" "}
                    {previewDoc.uploadedAt} by and between the parties listed
                    below.
                  </p>

                  <div className="bg-white rounded-lg p-4 border border-nexus-dark-200">
                    <h4 className="font-semibold text-nexus-dark-700 mb-3">
                      Signatories
                    </h4>
                    {previewDoc.parties.map((party, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between py-2 border-b border-nexus-dark-50 last:border-0"
                      >
                        <span className="text-nexus-dark-700 font-medium">
                          {party.name}
                        </span>
                        <span
                          className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                            party.signed
                              ? "bg-emerald-50 text-emerald-600"
                              : "bg-nexus-dark-100 text-nexus-dark-500"
                          }`}
                        >
                          {party.signed ? "Signed" : "Pending"}
                        </span>
                      </div>
                    ))}
                  </div>

                  {previewDoc.signature && (
                    <div className="bg-white rounded-lg p-4 border border-nexus-dark-200">
                      <h4 className="font-semibold text-nexus-dark-700 mb-2">
                        Your Signature
                      </h4>
                      <img
                        src={previewDoc.signature}
                        alt="Signature"
                        className="max-h-24 border border-nexus-dark-200 rounded-lg p-2"
                      />
                    </div>
                  )}

                  <p>
                    IN WITNESS WHEREOF, the parties have executed this agreement
                    as of the date set forth above.
                  </p>
                </div>
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-nexus-dark-100">
              <button className="flex items-center gap-2 px-4 py-2.5 border border-nexus-dark-200 rounded-xl text-sm font-semibold text-nexus-dark-600 hover:bg-nexus-dark-50 transition-colors">
                <Download className="h-4 w-4" />
                Download
              </button>
              <button
                onClick={() => setShowPreview(null)}
                className="flex-1 py-2.5 bg-nexus-dark-100 text-nexus-dark-600 rounded-xl text-sm font-semibold hover:bg-nexus-dark-200 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
