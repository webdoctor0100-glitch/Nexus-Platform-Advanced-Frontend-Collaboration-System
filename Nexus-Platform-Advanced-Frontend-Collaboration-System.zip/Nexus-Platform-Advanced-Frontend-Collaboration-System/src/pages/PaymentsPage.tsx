import { useState } from "react";
import { useStore } from "@/store/useStore";
import {
  Wallet,
  ArrowUpCircle,
  ArrowDownCircle,
  ArrowRightLeft,
  DollarSign,
  TrendingUp,
  X,
  CheckCircle,
  Clock,
  XCircle,
  AlertCircle,
} from "lucide-react";
import type { Transaction } from "@/types";

export default function PaymentsPage() {
  const { user, transactions, deals, addTransaction, fundDeal } = useStore();

  const [activeTab, setActiveTab] = useState<
    "overview" | "deposit" | "withdraw" | "transfer" | "funding"
  >("overview");

  const [amount, setAmount] = useState("");
  const [recipient, setRecipient] = useState("");
  const [selectedDeal, setSelectedDeal] = useState("");
  const [showConfirm, setShowConfirm] = useState(false);
  const [pendingAction, setPendingAction] = useState<{
    type: string;
    amount: number;
    target: string;
  } | null>(null);

  const activeDeals = deals.filter((d) => d.status === "funding");

  const handleAction = () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return;

    let target = "";
    switch (activeTab) {
      case "deposit":
        target = "Bank Transfer";
        break;
      case "withdraw":
        target = "Bank Account";
        break;
      case "transfer":
        target = recipient;
        break;
      case "funding":
        target = deals.find((d) => d.id === selectedDeal)?.entrepreneur || "";
        break;
    }

    setPendingAction({ type: activeTab, amount: amt, target });
    setShowConfirm(true);
  };

  const confirmAction = () => {
    if (!pendingAction) return;

    const tx: Transaction = {
      id: "tx" + Date.now(),
      amount: pendingAction.amount,
      type: pendingAction.type as Transaction["type"],
      sender:
        pendingAction.type === "deposit"
          ? pendingAction.target
          : user?.name || "You",
      receiver:
        pendingAction.type === "deposit"
          ? user?.name || "You"
          : pendingAction.target,
      status: "completed",
      date: new Date().toISOString().split("T")[0],
    };

    if (pendingAction.type === "funding" && selectedDeal) {
      fundDeal(selectedDeal, pendingAction.amount);
    } else {
      addTransaction(tx);
    }

    setShowConfirm(false);
    setPendingAction(null);
    setAmount("");
    setRecipient("");
    setSelectedDeal("");
    setActiveTab("overview");
  };

  const statusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-emerald-500" />;
      case "pending":
        return <Clock className="h-4 w-4 text-amber-500" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-rose-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-nexus-dark-400" />;
    }
  };

  const tabs = [
    { id: "overview", label: "Overview", icon: Wallet },
    { id: "deposit", label: "Deposit", icon: ArrowDownCircle },
    { id: "withdraw", label: "Withdraw", icon: ArrowUpCircle },
    { id: "transfer", label: "Transfer", icon: ArrowRightLeft },
  ];

  if (user?.role === "investor") {
    tabs.push({ id: "funding", label: "Fund Deal", icon: TrendingUp });
  }

  return (
    <div className="p-4 lg:p-6 space-y-6 animate-fade-in-up" id="payments-page">
      <h2 className="text-2xl font-bold text-nexus-dark-800">
        Payment Center
      </h2>

      {/* Wallet Balance Card */}
      <div className="bg-gradient-to-br from-nexus-dark-800 to-nexus-dark-900 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-white/15">
              <Wallet className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-white/60">Wallet Balance</p>
              <p className="text-3xl font-bold">
                ${(user?.walletBalance || 0).toLocaleString()}
              </p>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-white/10 backdrop-blur-sm">
            <DollarSign className="h-6 w-6" />
          </div>
        </div>
        <div className="flex gap-2">
          {tabs
            .filter((t) => t.id !== "overview")
            .map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id as typeof activeTab)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-sm font-medium transition-colors"
              >
                <t.icon className="h-3.5 w-3.5" />
                {t.label}
              </button>
            ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-nexus-dark-100 rounded-xl p-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.id
                ? "bg-white text-nexus-dark-800 shadow-sm"
                : "text-nexus-dark-500 hover:text-nexus-dark-700"
            }`}
          >
            <tab.icon className="h-4 w-4" />
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Action Forms */}
      {activeTab !== "overview" && (
        <div className="bg-white rounded-xl border border-nexus-dark-100 p-5">
          <h3 className="font-semibold text-nexus-dark-700 mb-4 capitalize">
            {activeTab}
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                Amount ($)
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-nexus-dark-400" />
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                  placeholder="0.00"
                  min="1"
                />
              </div>
            </div>

            {activeTab === "transfer" && (
              <div>
                <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                  Recipient
                </label>
                <input
                  type="text"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                  placeholder="Name or email"
                />
              </div>
            )}

            {activeTab === "funding" && (
              <div>
                <label className="block text-sm font-semibold text-nexus-dark-700 mb-1">
                  Select Deal
                </label>
                <select
                  value={selectedDeal}
                  onChange={(e) => setSelectedDeal(e.target.value)}
                  className="w-full px-4 py-2.5 border border-nexus-dark-200 rounded-xl focus:border-nexus-blue-500 outline-none text-sm"
                >
                  <option value="">Choose a deal...</option>
                  {activeDeals.map((deal) => (
                    <option key={deal.id} value={deal.id}>
                      {deal.title} (${deal.amount.toLocaleString()} target)
                    </option>
                  ))}
                </select>
              </div>
            )}

            <button
              onClick={handleAction}
              disabled={
                !amount ||
                parseFloat(amount) <= 0 ||
                (activeTab === "transfer" && !recipient) ||
                (activeTab === "funding" && !selectedDeal)
              }
              className="w-full py-3 bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-600 text-white rounded-xl font-semibold hover:from-nexus-blue-600 hover:to-nexus-purple-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-nexus-blue-500/25 transition-all"
            >
              {activeTab === "deposit" && "Deposit Funds"}
              {activeTab === "withdraw" && "Withdraw Funds"}
              {activeTab === "transfer" && "Send Transfer"}
              {activeTab === "funding" && "Fund Deal"}
            </button>
          </div>
        </div>
      )}

      {/* Transaction History */}
      <div className="bg-white rounded-xl border border-nexus-dark-100">
        <div className="p-5 border-b border-nexus-dark-100 flex items-center justify-between">
          <h3 className="font-semibold text-nexus-dark-700">
            Transaction History
          </h3>
          <span className="text-sm text-nexus-dark-400">
            {transactions.length} transactions
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-nexus-dark-100">
                <th className="text-left px-5 py-3 text-xs font-semibold text-nexus-dark-400 uppercase">
                  Type
                </th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-nexus-dark-400 uppercase">
                  Amount
                </th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-nexus-dark-400 uppercase hidden md:table-cell">
                  Sender
                </th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-nexus-dark-400 uppercase hidden md:table-cell">
                  Receiver
                </th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-nexus-dark-400 uppercase">
                  Status
                </th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-nexus-dark-400 uppercase hidden sm:table-cell">
                  Date
                </th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx) => (
                <tr
                  key={tx.id}
                  className="border-b border-nexus-dark-50 hover:bg-nexus-dark-50/50 transition-colors"
                >
                  <td className="px-5 py-3">
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full ${
                        tx.type === "deposit"
                          ? "bg-emerald-50 text-emerald-600"
                          : tx.type === "withdraw"
                          ? "bg-rose-50 text-rose-600"
                          : tx.type === "funding"
                          ? "bg-nexus-purple-50 text-nexus-purple-600"
                          : "bg-nexus-blue-50 text-nexus-blue-600"
                      }`}
                    >
                      {tx.type}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <span
                      className={`text-sm font-semibold ${
                        tx.type === "deposit" || tx.type === "transfer"
                          ? "text-emerald-600"
                          : "text-nexus-dark-700"
                      }`}
                    >
                      {tx.type === "deposit" || tx.type === "transfer"
                        ? "+"
                        : "-"}
                      ${tx.amount.toLocaleString()}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-sm text-nexus-dark-600 hidden md:table-cell">
                    {tx.sender}
                  </td>
                  <td className="px-5 py-3 text-sm text-nexus-dark-600 hidden md:table-cell">
                    {tx.receiver}
                  </td>
                  <td className="px-5 py-3">
                    <span className="flex items-center gap-1 text-sm">
                      {statusIcon(tx.status)}
                      <span className="text-nexus-dark-600 hidden sm:inline">
                        {tx.status}
                      </span>
                    </span>
                  </td>
                  <td className="px-5 py-3 text-sm text-nexus-dark-500 hidden sm:table-cell">
                    {tx.date}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirm && pendingAction && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl animate-fade-in-up">
            <div className="flex items-center justify-between p-5 border-b border-nexus-dark-100">
              <h3 className="font-bold text-lg text-nexus-dark-800">
                Confirm {pendingAction.type}
              </h3>
              <button
                onClick={() => setShowConfirm(false)}
                className="p-1.5 rounded-lg hover:bg-nexus-dark-50 text-nexus-dark-400"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="bg-nexus-dark-50 rounded-xl p-4 space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-nexus-dark-500">Amount</span>
                  <span className="text-sm font-bold text-nexus-dark-800">
                    ${pendingAction.amount.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-nexus-dark-500">Type</span>
                  <span className="text-sm font-semibold text-nexus-dark-700 capitalize">
                    {pendingAction.type}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-nexus-dark-500">
                    {pendingAction.type === "deposit" ? "From" : "To"}
                  </span>
                  <span className="text-sm font-semibold text-nexus-dark-700">
                    {pendingAction.target}
                  </span>
                </div>
              </div>
              <p className="text-xs text-nexus-dark-400">
                This is a simulated transaction. No real money will be moved.
              </p>
            </div>
            <div className="flex gap-3 p-5 border-t border-nexus-dark-100">
              <button
                onClick={() => setShowConfirm(false)}
                className="flex-1 py-2.5 border border-nexus-dark-200 rounded-xl text-sm font-semibold text-nexus-dark-600 hover:bg-nexus-dark-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={confirmAction}
                className="flex-1 py-2.5 bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-600 text-white rounded-xl text-sm font-semibold hover:from-nexus-blue-600 hover:to-nexus-purple-700 transition-all"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
