import { useStore } from "@/store/useStore";
import {
  Calendar,
  TrendingUp,
  Wallet,
  FileText,
  Users,
  ArrowUpRight,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  DollarSign,
} from "lucide-react";

export default function DashboardPage() {
  const { user, meetings, transactions, documents, deals } = useStore();

  const confirmedMeetings = meetings.filter((m) => m.status === "confirmed");
  const pendingMeetings = meetings.filter((m) => m.status === "pending");
  const recentTx = transactions.slice(0, 5);
  const activeDeals = deals.filter((d) => d.status === "funding");

  const stats = [
    {
      label: "Wallet Balance",
      value: `$${(user?.walletBalance || 0).toLocaleString()}`,
      icon: Wallet,
      color: "from-emerald-500 to-teal-600",
      bg: "bg-emerald-50",
    },
    {
      label: "Active Deals",
      value: activeDeals.length.toString(),
      icon: TrendingUp,
      color: "from-nexus-blue-500 to-nexus-blue-700",
      bg: "bg-nexus-blue-50",
    },
    {
      label: "Documents",
      value: documents.length.toString(),
      icon: FileText,
      color: "from-nexus-purple-500 to-nexus-purple-700",
      bg: "bg-nexus-purple-50",
    },
    {
      label: "Meetings",
      value: confirmedMeetings.length.toString(),
      icon: Users,
      color: "from-nexus-amber-500 to-nexus-amber-600",
      bg: "bg-nexus-amber-50",
    },
  ];

  const statusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-emerald-500" />;
      case "pending":
        return <Clock className="h-4 w-4 text-amber-500" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-rose-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-nexus-dark-400" />;
    }
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 animate-fade-in-up" id="dashboard-page">
      {/* Welcome */}
      <div>
        <h2 className="text-2xl font-bold text-nexus-dark-800">
          Welcome back, {user?.name}!
        </h2>
        <p className="text-nexus-dark-500 mt-1">
          Here's what's happening with your{" "}
          {user?.role === "investor" ? "investments" : "fundraising"} today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="bg-white rounded-xl p-4 border border-nexus-dark-100 hover:shadow-lg hover:shadow-nexus-dark-200/30 transition-all"
          >
            <div className="flex items-center justify-between mb-3">
              <div className={`p-2 rounded-lg ${stat.bg}`}>
                <stat.icon
                  className={`h-5 w-5 bg-gradient-to-br ${stat.color} bg-clip-text text-transparent`}
                />
              </div>
              <ArrowUpRight className="h-4 w-4 text-nexus-dark-300" />
            </div>
            <p className="text-2xl font-bold text-nexus-dark-800">
              {stat.value}
            </p>
            <p className="text-xs text-nexus-dark-400 mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <div className="bg-white rounded-xl border border-nexus-dark-100 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-nexus-dark-700">
              Recent Transactions
            </h3>
            <button
              onClick={() => useStore.getState().setCurrentPage("payments")}
              className="text-sm text-nexus-blue-500 hover:text-nexus-blue-600 font-medium"
            >
              View All
            </button>
          </div>
          <div className="space-y-3">
            {recentTx.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between py-2 border-b border-nexus-dark-50 last:border-0"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2 rounded-lg ${
                      tx.type === "deposit" || tx.type === "funding"
                        ? "bg-nexus-blue-50"
                        : tx.type === "withdraw"
                        ? "bg-nexus-rose-50"
                        : "bg-nexus-emerald-50"
                    }`}
                  >
                    <DollarSign
                      className={`h-4 w-4 ${
                        tx.type === "deposit"
                          ? "text-nexus-blue-500"
                          : tx.type === "withdraw"
                          ? "text-nexus-rose-500"
                          : "text-nexus-emerald-500"
                      }`}
                    />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-nexus-dark-700">
                      {tx.type.charAt(0).toUpperCase() + tx.type.slice(1)}
                    </p>
                    <p className="text-xs text-nexus-dark-400">
                      {tx.receiver} • {tx.date}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p
                    className={`text-sm font-semibold ${
                      tx.type === "deposit" || tx.type === "transfer"
                        ? "text-emerald-600"
                        : "text-nexus-dark-700"
                    }`}
                  >
                    {tx.type === "deposit" || tx.type === "transfer"
                      ? "+"
                      : "-"}
                    ${tx.amount.toLocaleString()}
                  </p>
                  <div className="flex items-center gap-1 justify-end">
                    {statusIcon(tx.status)}
                    <span className="text-xs text-nexus-dark-400">
                      {tx.status}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Meetings */}
        <div className="bg-white rounded-xl border border-nexus-dark-100 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-nexus-dark-700">
              Upcoming Meetings
            </h3>
            <button
              onClick={() => useStore.getState().setCurrentPage("calendar")}
              className="text-sm text-nexus-blue-500 hover:text-nexus-blue-600 font-medium"
            >
              Calendar
            </button>
          </div>
          <div className="space-y-3">
            {[...confirmedMeetings, ...pendingMeetings].slice(0, 5).map((m) => (
              <div
                key={m.id}
                className="flex items-center justify-between py-2 border-b border-nexus-dark-50 last:border-0"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-nexus-purple-50">
                    <Calendar className="h-4 w-4 text-nexus-purple-500" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-nexus-dark-700">
                      {m.title}
                    </p>
                    <p className="text-xs text-nexus-dark-400">
                      {m.with} • {m.date} • {m.startTime}
                    </p>
                  </div>
                </div>
                <span
                  className={`text-xs font-medium px-2 py-1 rounded-full ${
                    m.status === "confirmed"
                      ? "bg-emerald-50 text-emerald-600"
                      : m.status === "declined"
                      ? "bg-rose-50 text-rose-600"
                      : "bg-amber-50 text-amber-600"
                  }`}
                >
                  {m.status}
                </span>
              </div>
            ))}
            {[...confirmedMeetings, ...pendingMeetings].length === 0 && (
              <p className="text-sm text-nexus-dark-400 text-center py-6">
                No upcoming meetings
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Active Deals */}
      {activeDeals.length > 0 && (
        <div className="bg-white rounded-xl border border-nexus-dark-100 p-5">
          <h3 className="font-semibold text-nexus-dark-700 mb-4">
            Active Deals
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeDeals.map((deal) => {
              const progress = (deal.raised / deal.amount) * 100;
              return (
                <div
                  key={deal.id}
                  className="border border-nexus-dark-100 rounded-xl p-4 hover:border-nexus-blue-200 transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-semibold text-nexus-dark-800">
                        {deal.title}
                      </h4>
                      <p className="text-xs text-nexus-dark-500 mt-1 line-clamp-2">
                        {deal.description}
                      </p>
                    </div>
                    <span className="text-xs font-medium px-2 py-1 rounded-full bg-nexus-blue-50 text-nexus-blue-600">
                      {deal.status}
                    </span>
                  </div>
                  <div className="mb-2">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-nexus-dark-500">
                        ${deal.raised.toLocaleString()} raised
                      </span>
                      <span className="font-semibold text-nexus-dark-700">
                        ${deal.amount.toLocaleString()}
                      </span>
                    </div>
                    <div className="h-2 bg-nexus-dark-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-nexus-blue-500 to-nexus-purple-500 rounded-full transition-all"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    <p className="text-xs text-nexus-dark-400 mt-1">
                      {progress.toFixed(0)}% funded
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
