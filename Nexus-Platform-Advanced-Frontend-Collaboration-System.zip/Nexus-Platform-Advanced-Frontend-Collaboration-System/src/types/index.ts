export type UserRole = "investor" | "entrepreneur";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  walletBalance: number;
}

export interface Meeting {
  id: string;
  title: string;
  date: string;
  startTime: string;
  endTime: string;
  status: "pending" | "accepted" | "declined" | "confirmed";
  with: string;
  withRole: UserRole;
  withAvatar?: string;
  notes?: string;
}

export interface Transaction {
  id: string;
  amount: number;
  type: "deposit" | "withdraw" | "transfer" | "funding";
  sender: string;
  receiver: string;
  status: "completed" | "pending" | "failed";
  date: string;
  dealRef?: string;
}

export interface Document {
  id: string;
  title: string;
  type: "pdf" | "doc" | "docx" | "other";
  size: string;
  status: "draft" | "in_review" | "signed";
  uploadedAt: string;
  signedAt?: string;
  signature?: string;
  parties: { name: string; signed: boolean }[];
}

export interface Deal {
  id: string;
  title: string;
  description: string;
  amount: number;
  raised: number;
  status: "open" | "funding" | "closed";
  entrepreneur: string;
  investors: { name: string; amount: number }[];
}
