import { useEffect } from "react";
import { useStore } from "@/store/useStore";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import Walkthrough from "@/components/Walkthrough";
import LoginPage from "@/pages/LoginPage";
import DashboardPage from "@/pages/DashboardPage";
import CalendarPage from "@/pages/CalendarPage";
import VideoCallPage from "@/pages/VideoCallPage";
import DocumentsPage from "@/pages/DocumentsPage";
import PaymentsPage from "@/pages/PaymentsPage";
import SecurityPage from "@/pages/SecurityPage";
export default function App() {
  const { isAuthenticated, otpVerified, currentPage } =
    useStore();

  // Reset on first visit
  useEffect(() => {
    const store = useStore.getState();
    if (store.walkthroughComplete === undefined) {
      store.setWalkthroughComplete(false);
    }
  }, []);

  if (!isAuthenticated || !otpVerified) {
    return (
      <>
        <LoginPage />
        <Walkthrough />
      </>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <DashboardPage />;
      case "calendar":
        return <CalendarPage />;
      case "video-call":
        return <VideoCallPage />;
      case "documents":
        return <DocumentsPage />;
      case "payments":
        return <PaymentsPage />;
      case "security":
        return <SecurityPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-nexus-dark-50">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto">{renderPage()}</main>
      </div>
      <Walkthrough />
    </div>
  );
}
