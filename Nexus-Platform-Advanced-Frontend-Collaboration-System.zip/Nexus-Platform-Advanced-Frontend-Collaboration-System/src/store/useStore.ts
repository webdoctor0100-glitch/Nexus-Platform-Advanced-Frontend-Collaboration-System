import { create } from "zustand";
import { User, Meeting, Transaction, Document, Deal, UserRole } from "@/types";

interface AppState {
  // Auth
  user: User | null;
  isAuthenticated: boolean;
  is2FARequired: boolean;
  otpVerified: boolean;
  loginStep: number;
  login: (email: string, password: string, role: UserRole) => void;
  verifyOTP: (otp: string) => boolean;
  logout: () => void;

  // Meetings
  meetings: Meeting[];
  addMeeting: (meeting: Meeting) => void;
  updateMeetingStatus: (
    id: string,
    status: Meeting["status"]
  ) => void;
  deleteMeeting: (id: string) => void;

  // Transactions
  transactions: Transaction[];
  addTransaction: (tx: Transaction) => void;

  // Documents
  documents: Document[];
  addDocument: (doc: Document) => void;
  updateDocumentStatus: (id: string, status: Document["status"]) => void;
  signDocument: (id: string, signature: string) => void;
  deleteDocument: (id: string) => void;

  // Deals
  deals: Deal[];
  fundDeal: (dealId: string, amount: number) => void;

  // Navigation
  currentPage: string;
  setCurrentPage: (page: string) => void;
  sidebarOpen: boolean;
  toggleSidebar: () => void;

  // Walkthrough
  walkthroughComplete: boolean;
  setWalkthroughComplete: (v: boolean) => void;
}

export const useStore = create<AppState>((set, get) => ({
  // Auth defaults
  user: null,
  isAuthenticated: false,
  is2FARequired: false,
  otpVerified: false,
  loginStep: 1,

  login: (email, _password, role) => {
    const mockUser: User = {
      id: "usr_" + Math.random().toString(36).slice(2, 8),
      name: email.split("@")[0],
      email,
      role,
      walletBalance: role === "investor" ? 250000 : 50000,
    };
    set({ user: mockUser, isAuthenticated: true, is2FARequired: true, loginStep: 2 });
  },

  verifyOTP: (otp) => {
    if (otp === "123456") {
      set({ otpVerified: true, loginStep: 3 });
      return true;
    }
    return false;
  },

  logout: () =>
    set({
      user: null,
      isAuthenticated: false,
      is2FARequired: false,
      otpVerified: false,
      loginStep: 1,
      currentPage: "login",
    }),

  // Meetings
  meetings: [
    {
      id: "m1",
      title: "Series A Pitch Discussion",
      date: "2026-04-15",
      startTime: "10:00",
      endTime: "11:00",
      status: "confirmed",
      with: "Sarah Chen",
      withRole: "entrepreneur",
      notes: "Discussing AI-driven logistics platform",
    },
    {
      id: "m2",
      title: "Due Diligence Review",
      date: "2026-04-16",
      startTime: "14:00",
      endTime: "15:30",
      status: "pending",
      with: "Marcus Rivera",
      withRole: "investor",
      notes: "Review financial statements",
    },
    {
      id: "m3",
      title: "Product Demo",
      date: "2026-04-18",
      startTime: "09:00",
      endTime: "10:00",
      status: "pending",
      with: "Emily Park",
      withRole: "entrepreneur",
      notes: "Live demo of MVP",
    },
  ],

  addMeeting: (meeting) =>
    set((s) => ({ meetings: [...s.meetings, meeting] })),

  updateMeetingStatus: (id, status) =>
    set((s) => ({
      meetings: s.meetings.map((m) => (m.id === id ? { ...m, status } : m)),
    })),

  deleteMeeting: (id) =>
    set((s) => ({ meetings: s.meetings.filter((m) => m.id !== id) })),

  // Transactions
  transactions: [
    {
      id: "tx1",
      amount: 50000,
      type: "deposit",
      sender: "Bank Transfer",
      receiver: "You",
      status: "completed",
      date: "2026-04-10",
    },
    {
      id: "tx2",
      amount: 15000,
      type: "funding",
      sender: "You",
      receiver: "TechVenture Inc.",
      status: "completed",
      date: "2026-04-08",
      dealRef: "Series A - TechVenture",
    },
    {
      id: "tx3",
      amount: 5000,
      type: "withdraw",
      sender: "You",
      receiver: "Bank Account",
      status: "completed",
      date: "2026-04-05",
    },
    {
      id: "tx4",
      amount: 25000,
      type: "transfer",
      sender: "Alex Morgan",
      receiver: "You",
      status: "completed",
      date: "2026-04-03",
    },
    {
      id: "tx5",
      amount: 10000,
      type: "funding",
      sender: "You",
      receiver: "GreenEnergy Labs",
      status: "pending",
      date: "2026-04-12",
      dealRef: "Seed - GreenEnergy",
    },
  ],

  addTransaction: (tx) =>
    set((s) => ({ transactions: [tx, ...s.transactions] })),

  // Documents
  documents: [
    {
      id: "d1",
      title: "Series A Investment Agreement",
      type: "pdf",
      size: "2.4 MB",
      status: "in_review",
      uploadedAt: "2026-04-01",
      parties: [
        { name: "You", signed: false },
        { name: "Sarah Chen", signed: false },
      ],
    },
    {
      id: "d2",
      title: "NDA - TechVenture Inc.",
      type: "pdf",
      size: "1.1 MB",
      status: "signed",
      uploadedAt: "2026-03-28",
      signedAt: "2026-03-30",
      signature: "data:image/svg+xml;base64,PHN2ZyB3...",
      parties: [
        { name: "You", signed: true },
        { name: "Sarah Chen", signed: true },
      ],
    },
    {
      id: "d3",
      title: "Term Sheet Draft",
      type: "docx",
      size: "856 KB",
      status: "draft",
      uploadedAt: "2026-04-05",
      parties: [
        { name: "You", signed: false },
        { name: "Marcus Rivera", signed: false },
      ],
    },
  ],

  addDocument: (doc) =>
    set((s) => ({ documents: [doc, ...s.documents] })),

  updateDocumentStatus: (id, status) =>
    set((s) => ({
      documents: s.documents.map((d) => (d.id === id ? { ...d, status } : d)),
    })),

  signDocument: (id, signature) =>
    set((s) => ({
      documents: s.documents.map((d) => {
        if (d.id !== id) return d;
        const updatedParties = d.parties.map((p) =>
          p.name === "You" ? { ...p, signed: true } : p
        );
        return {
          ...d,
          signature,
          signedAt: new Date().toISOString().split("T")[0],
          parties: updatedParties,
          status: updatedParties.every((p) => p.signed)
            ? ("signed" as const)
            : d.status,
        };
      }),
    })),

  deleteDocument: (id) =>
    set((s) => ({ documents: s.documents.filter((d) => d.id !== id) })),

  // Deals
  deals: [
    {
      id: "deal1",
      title: "AI-Driven Logistics Platform",
      description:
        "Revolutionizing supply chain with predictive AI. $2M ARR in 18 months.",
      amount: 500000,
      raised: 325000,
      status: "funding",
      entrepreneur: "Sarah Chen",
      investors: [
        { name: "Marcus Rivera", amount: 200000 },
        { name: "You", amount: 125000 },
      ],
    },
    {
      id: "deal2",
      title: "GreenEnergy Labs",
      description:
        "Next-gen solar storage solutions for residential markets.",
      amount: 250000,
      raised: 100000,
      status: "funding",
      entrepreneur: "Emily Park",
      investors: [{ name: "You", amount: 100000 }],
    },
    {
      id: "deal3",
      title: "HealthTech Wearable",
      description:
        "Continuous glucose monitoring wearable, non-invasive.",
      amount: 750000,
      raised: 750000,
      status: "closed",
      entrepreneur: "Dr. James Wilson",
      investors: [
        { name: "You", amount: 300000 },
        { name: "VentureFund Capital", amount: 450000 },
      ],
    },
  ],

  fundDeal: (dealId, amount) => {
    const state = get();
    const deal = state.deals.find((d) => d.id === dealId);
    if (!deal || !state.user) return;

    set((s) => ({
      deals: s.deals.map((d) => {
        if (d.id !== dealId) return d;
        const newRaised = d.raised + amount;
        return {
          ...d,
          raised: newRaised,
          status:
            newRaised >= d.amount ? ("closed" as const) : d.status,
          investors: [...d.investors, { name: s.user!.name, amount }],
        };
      }),
      transactions: [
        {
          id: "tx" + Date.now(),
          amount,
          type: "funding",
          sender: state.user!.name,
          receiver: deal.entrepreneur,
          status: "completed",
          date: new Date().toISOString().split("T")[0],
          dealRef: deal.title,
        },
        ...s.transactions,
      ],
      user: s.user
        ? { ...s.user, walletBalance: s.user.walletBalance - amount }
        : null,
    }));
  },

  // Navigation
  currentPage: "login",
  setCurrentPage: (page) => set({ currentPage: page }),
  sidebarOpen: true,
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),

  // Walkthrough
  walkthroughComplete: false,
  setWalkthroughComplete: (v) => set({ walkthroughComplete: v }),
}));
