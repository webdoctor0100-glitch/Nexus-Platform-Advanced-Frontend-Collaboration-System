import { useStore } from "@/store/useStore";
import { cn } from "@/utils/cn";
import {
  LayoutDashboard,
  Calendar,
  Video,
  FileText,
  CreditCard,
  Shield,
  LogOut,
  ChevronLeft,
  User,
  Building2,
  Zap,
} from "lucide-react";

const investorLinks = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "calendar", label: "Meetings", icon: Calendar },
  { id: "video-call", label: "Video Call", icon: Video },
  { id: "documents", label: "Documents", icon: FileText },
  { id: "payments", label: "Payments", icon: CreditCard },
  { id: "security", label: "Security", icon: Shield },
];

const entrepreneurLinks = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "calendar", label: "Meetings", icon: Calendar },
  { id: "video-call", label: "Video Call", icon: Video },
  { id: "documents", label: "Documents", icon: FileText },
  { id: "payments", label: "Payments", icon: CreditCard },
  { id: "security", label: "Security", icon: Shield },
];

export default function Sidebar() {
  const {
    user,
    currentPage,
    setCurrentPage,
    sidebarOpen,
    toggleSidebar,
    logout,
  } = useStore();

  const links =
    user?.role === "entrepreneur" ? entrepreneurLinks : investorLinks;

  return (
    <>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-40 lg:hidden"
          onClick={toggleSidebar}
        />
      )}

      <aside
        className={cn(
          "fixed top-0 left-0 z-50 h-full bg-white border-r border-nexus-dark-200 flex flex-col transition-all duration-300",
          sidebarOpen ? "w-64 translate-x-0" : "w-64 -translate-x-full lg:translate-x-0 lg:w-20",
          "lg:relative"
        )}
        id="sidebar"
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 h-16 border-b border-nexus-dark-200 shrink-0">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-nexus-blue-500 to-nexus-purple-600 flex items-center justify-center shrink-0">
            <Zap className="h-5 w-5 text-white" />
          </div>
          <span
            className={cn(
              "font-bold text-lg text-nexus-dark-800 transition-opacity",
              !sidebarOpen && "lg:hidden"
            )}
          >
            Nexus
          </span>
        </div>

        {/* Nav Links */}
        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {links.map((link) => (
            <button
              key={link.id}
              onClick={() => setCurrentPage(link.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200",
                currentPage === link.id
                  ? "bg-nexus-blue-50 text-nexus-blue-600 shadow-sm"
                  : "text-nexus-dark-500 hover:bg-nexus-dark-50 hover:text-nexus-dark-700"
              )}
            >
              <link.icon className="h-5 w-5 shrink-0" />
              <span className={cn(!sidebarOpen && "lg:hidden")}>
                {link.label}
              </span>
            </button>
          ))}
        </nav>

        {/* User & Logout */}
        <div className="border-t border-nexus-dark-200 p-3 space-y-2">
          <div
            className={cn(
              "flex items-center gap-3 px-3 py-2 rounded-xl bg-nexus-dark-50",
              !sidebarOpen && "lg:justify-center"
            )}
          >
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-nexus-purple-400 to-nexus-blue-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
              {user?.name?.[0]?.toUpperCase() || "U"}
            </div>
            <div className={cn("flex-1 min-w-0", !sidebarOpen && "lg:hidden")}>
              <p className="text-sm font-semibold text-nexus-dark-700 truncate">
                {user?.name || "User"}
              </p>
              <p className="text-xs text-nexus-dark-400 flex items-center gap-1">
                {user?.role === "investor" ? (
                  <Building2 className="h-3 w-3" />
                ) : (
                  <User className="h-3 w-3" />
                )}
                {user?.role || "guest"}
              </p>
            </div>
          </div>

          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-nexus-rose-500 hover:bg-nexus-rose-50 transition-colors"
          >
            <LogOut className="h-5 w-5 shrink-0" />
            <span className={cn(!sidebarOpen && "lg:hidden")}>Sign Out</span>
          </button>
        </div>

        {/* Collapse toggle - desktop only */}
        <button
          onClick={toggleSidebar}
          className="hidden lg:flex absolute -right-3 top-20 h-6 w-6 rounded-full bg-white border border-nexus-dark-200 items-center justify-center shadow-sm hover:bg-nexus-dark-50 transition-colors"
        >
          <ChevronLeft
            className={cn(
              "h-3 w-3 text-nexus-dark-400 transition-transform",
              !sidebarOpen && "rotate-180"
            )}
          />
        </button>
      </aside>
    </>
  );
}
