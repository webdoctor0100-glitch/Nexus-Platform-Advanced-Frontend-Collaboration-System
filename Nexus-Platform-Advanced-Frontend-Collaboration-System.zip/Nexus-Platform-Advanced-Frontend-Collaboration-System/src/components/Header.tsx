import { useStore } from "@/store/useStore";
import { Bell, Menu, Search } from "lucide-react";

const pageTitles: Record<string, string> = {
  dashboard: "Dashboard",
  calendar: "Meeting Calendar",
  "video-call": "Video Call",
  documents: "Document Chamber",
  payments: "Payment Center",
  security: "Security & Access",
};

export default function Header() {
  const { user, currentPage, toggleSidebar } = useStore();

  const title = pageTitles[currentPage] || "Nexus";

  return (
    <header className="h-16 bg-white border-b border-nexus-dark-200 flex items-center justify-between px-4 lg:px-6 sticky top-0 z-30">
      <div className="flex items-center gap-3">
        <button
          onClick={toggleSidebar}
          className="p-2 rounded-lg hover:bg-nexus-dark-50 text-nexus-dark-500 lg:hidden"
        >
          <Menu className="h-5 w-5" />
        </button>
        <h1 className="text-xl font-bold text-nexus-dark-800">{title}</h1>
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden sm:flex items-center gap-2 bg-nexus-dark-50 rounded-lg px-3 py-1.5 border border-nexus-dark-200">
          <Search className="h-4 w-4 text-nexus-dark-400" />
          <input
            type="text"
            placeholder="Search..."
            className="bg-transparent text-sm text-nexus-dark-700 placeholder-nexus-dark-400 outline-none w-40"
          />
        </div>

        <button className="relative p-2 rounded-lg hover:bg-nexus-dark-50 text-nexus-dark-500">
          <Bell className="h-5 w-5" />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-nexus-rose-500 ring-2 ring-white" />
        </button>

        <div className="flex items-center gap-2 pl-3 border-l border-nexus-dark-200">
          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-nexus-purple-400 to-nexus-blue-500 flex items-center justify-center text-white text-xs font-bold">
            {user?.name?.[0]?.toUpperCase() || "U"}
          </div>
          <span className="text-sm font-medium text-nexus-dark-700 hidden sm:block">
            {user?.name || "User"}
          </span>
        </div>
      </div>
    </header>
  );
}
