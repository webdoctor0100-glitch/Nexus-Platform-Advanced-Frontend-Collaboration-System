import { useStore } from "@/store/useStore";
import { Joyride, STATUS } from "react-joyride";
import type { Step } from "react-joyride";

const steps: Step[] = [
  {
    target: "#sidebar",
    title: "Navigation Sidebar",
    content:
      "Access all Nexus modules from here. Switch between Dashboard, Meetings, Video Call, Documents, Payments, and Security.",
    placement: "right",
  },
  {
    target: "#dashboard-page",
    title: "Dashboard",
    content:
      "Your central hub. View wallet balance, active deals, recent transactions, and upcoming meetings at a glance.",
    placement: "center",
  },
  {
    target: "#calendar-page",
    title: "Meeting Calendar",
    content:
      "Schedule meetings with investors or entrepreneurs. Accept or decline meeting requests and manage your availability.",
    placement: "top",
  },
  {
    target: "#video-call-page",
    title: "Video Calling",
    content:
      "Start secure video calls. Toggle camera/mic, share your screen, and collaborate in real-time.",
    placement: "top",
  },
  {
    target: "#documents-page",
    title: "Document Chamber",
    content:
      "Upload, preview, and e-sign contracts and agreements. Track document status from Draft to Signed.",
    placement: "top",
  },
  {
    target: "#payments-page",
    title: "Payment Center",
    content:
      "Deposit, withdraw, transfer funds, and invest in deals. All transactions are recorded in your history.",
    placement: "top",
  },
  {
    target: "#security-page",
    title: "Security & Access",
    content:
      "Manage your password, two-factor authentication, and view your role-based access permissions.",
    placement: "top",
  },
];

export default function Walkthrough() {
  const { walkthroughComplete, setWalkthroughComplete } = useStore();

  const handleEvent = (data: { status: string }) => {
    const { status } = data;
    const finishedStatuses: string[] = [STATUS.FINISHED, STATUS.SKIPPED];

    if (finishedStatuses.includes(status)) {
      setWalkthroughComplete(true);
    }
  };

  if (walkthroughComplete) return null;

  return (
    <Joyride
      steps={steps}
      run={!walkthroughComplete}
      continuous
      onEvent={handleEvent}
    />
  );
}
